# v2.6 검증 기록

검증일 2026-09-09 · Linux / Python 3.12.14 · 코드 해시 `0cf6b3d0b28a3a71a0ead8b8e79ca9e774be01c81baae53d9aa528f05d46b298`.
실행 환경의 패키지 버전과 파일별 해시는 각 JSON의 runtime 및 SOURCE_MANIFEST.json에 있다.

| 검사 | 관측 결과 | 근거 |
|---|---|---|
| 기존 검증 | 55/55 통과 | `v26_verify.log` |
| 회귀·화면 검사 | 167/167, 실패·오류·생략 0 | `v26_tests.log`, `v26_test_summary.json` |
| 신규 검사 | 핵심 16개와 UI 2개 | `tests/test_layers_26.py`, `tests/test_ui_review.py` |
| 외부 STL | 16개 원본·정리 후보 모두 전 층 계산 | `v26_real_models.json` |
| GB 화면 | 두 입력 모두 212층, 이동·세부 오버레이, 예외 0 | `v26_gb_app.json` |
| 기존 결과 | 3D 필드 및 단면 기하·진단 일치, 지지·한 층 후보량 보존 | `v26_legacy_comparison.json` |
| 기존 점수 | Good 100.0(A), Moderate 85.2(B), Bad 58.9(F) | `v26_sample_scores.json` |
| Cura 저장 예측 R² | 0.9784086106593225 | `cura_original_v26.json` |
| 현재의 기존 3D 항 재계산 R² | 0.978431909544024 | `cura_current_v26.json` |
| 원자료 | cura_run 29개 모두 원본 dfm2.zip과 바이트 일치 | `raw_data_integrity_v26.json` |

근거 파일은 별도 표기한 tests를 제외하면 validation 폴더에 있다. 기본 검증과 회귀 검사는 목적이 겹치며 독립 제조 실험 수가 아니다.

## 재검토 재현과 성능

v2.5 기준은 `v25_comparison_baseline.json`, v2.6은 `v26_review_reproduction.json`이다.
스크립트 `reproduce_review.py`는 동일 NIST 파일과 반지름 25mm·subdivision 6 구를 사용한다.
+Z, 층 높이 0.2mm, 선폭 0.4mm, 경사 45°로 각각 한 번 측정했다. 입력·코드 해시를 기록했다.

| 작업 | v2.5 초 | v2.6 초 |
|---|---:|---:|
| NIST_posZ 단면 검토 | 3.923 | 4.094 |
| sphere_r25_sub6 단면 검토 | 7.219 | 5.173 |
| 구 기존 3D 분석만 | 9.529 | 9.382 |

프로파일은 별도 실행이므로 위 실측 시간과 합산하지 않는다. 구의 hash_fallback 호출 774→27회,
자체 시간 약 1.303→0.0135초. 전체 속도는 다른 연산과 분류 비용에도 영향을 받는다.
NIST의 총 시간 개선은 확인하지 못했다. 고정 속도비나 리뷰의 6방향 시간을 이번 실측으로 주장하지 않는다.

NIST 한 층 검사: 우선 검토 61→0층, 작은 세부 61층에 합 0.004140852844466045mm² 보존.
지지: 우선 검토 15→14층, 후보 총합 61.053961686345595mm² 보존.
선폭: 우선 검토 20층, 6.113452235668285mm² 유지.
이는 후보 분류 변화이며 오검출을 입증한 결과가 아니다.

## 외부 STL

입력 mm, +Z, 장비 250×250×250mm, FDM 기본 설정이다.
외부 16개는 GB 1개·Benchy 1개·Prusa 부품 14개다. 원본과 정리본을 독립 부품 32개로 세지 않는다.
각 STL의 출처·해시는 external_model_sources.json에 있고 외부 STL 자체는 재배포하지 않는다.

| 파일 | 원본 확정 / 요청 층 | 정리본 단면 상태 | 기존 3D 상태 | 기존 점수 |
|---|---:|---|---|---:|
| GB.stl | 212 / 212 | complete | invalid_input | 미산출 |
| 3DBenchy.stl | 240 / 240 | complete | invalid_input | 미산출 |
| y-belt-holder.stl | 90 / 90 | complete | indeterminate | 미산출 |
| y-motor-holder.stl | 95 / 95 | complete | indeterminate | 미산출 |
| x-carriage.stl | 75 / 75 | complete | indeterminate | 미산출 |
| extruder-cover.stl | 115 / 115 | complete | invalid_input | 미산출 |
| z-axis-top.stl | 80 / 80 | complete | invalid_input | 미산출 |
| LCD-knob.stl | 40 / 40 | complete | indeterminate | 미산출 |
| y-rod-holder.stl | 50 / 50 | complete | eligible | 93.5 |
| z-screw-cover.stl | 25 / 25 | complete | indeterminate | 미산출 |
| x-end-idler.stl | 290 / 290 | complete | blocked | 미산출 |
| x-end-motor.stl | 290 / 290 | complete | blocked | 미산출 |
| Einsy-base.stl | 190 / 190 | complete | invalid_input | 미산출 |
| fs-cover.stl | 20 / 20 | complete | eligible | 85.7 |
| fan-shroud.stl | 100 / 100 | complete | indeterminate | 미산출 |
| extruder-body.stl | 100 / 100 | complete | indeterminate | 미산출 |

각 입력 파일은 실행 전후 해시가 동일하다. v2.5와 비교할 때 engine_version과 layer_review를 제외한 기존 3D 필드가 모두 같다.
단면 상태·높이·면적·둘레·진단·선폭 수치도 같다. 지지·한 층은 과거 area와 새 candidate_area를 대조했고,
새 area+detail_area도 같은지 상대·절대 허용오차 1e-10으로 확인했다. NIST와 구의 재현 결과에도 같은 검사를 적용했다.

GB 화면 검사는 AppTest 샘플 입력에 실제 메시를 주입해 원본·정리 후보, 슬라이더,
작은 선폭·작은 지지·작은 한 층을 포함한 오버레이를 실행했다. 업로드 위젯·실제 브라우저 픽셀·GPU 검사는 아니다.
GB의 기존 3D 점수는 계속 미산출이다. 단면 완료를 메시 복구나 제조 가능 판정으로 해석하지 않는다.

## 범위와 재실행

실제 Cura 재슬라이싱, 실물 출력, Windows 배치 및 노트북 브라우저 성능은 이번 환경에서 실행하지 않았다.
일부 Streamlit 로그에는 기존 폭 인자의 폐기 안내와 비FDM 표의 자동 자료형 보정 메시지가 남지만 AppTest 예외와 검사 실패는 없었다.
단면 전체 완료는 요청한 평면의 계산 완료이며, 층 사이의 모든 특징과 실제 제조 품질을 보장하지 않는다.
원인 불명 내부 껍질, 정밀도 이하 형상, 과도한 경계 겹침과 계산 한도는 계속 적용 범위의 한계다.

```bash
python -m pip install -r requirements-tested.txt
python verify.py
python -m unittest discover -s tests -v
python validation/reproduce_review.py . reproduction_new.json
python audit_models.py GB.stl another.stl --out audit_new.json
python cura_check.py analyze --csv cura_run/measurements.csv --out reference_new.json
python cura_check.py analyze --csv cura_run/measurements.csv --recompute-terms --out current_new.json
```

새 파일명으로 저장한다. 과거 자료는 history_v25 등 버전별 폴더에 보존했으며,
v2.5와 v2.6의 같은 입력 비교 기준은 이번에 생성한 v25_comparison_baseline.json이다.
현재 변경의 차이는 루트 CHANGES.patch, 파일 무결성은 SOURCE_MANIFEST.json으로 확인한다.
