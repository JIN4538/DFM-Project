# v2.6 변경 근거와 코드 위치

첨부 리뷰 원문은 `validation/v25_user_review.md`, 판단과 개선 계획은 `docs/AM_DFM_v26_재검토와_개선계획.md`에 있다.
리뷰 A/B/E는 실제 또는 잠재 결함으로 반영했다. C는 프로파일링 후 최적화할 과제이고 D의 추정 기반 조기 거부는 반례 위험 때문에 적용하지 않았다.

| 파일 | 변경 |
|---|---|
| `src/core/layer_regions.py` | 공통 후보 분류와 검사별 ‘전체 성분 해당’ 조건. 세부 삭제 없이 후보 면적·개수 보존 |
| `src/core/layer_review.py` | 지지·한 층 검사의 우선 검토·작은 세부·후보 집계, 실패 시 null, 세 검사 공통 details_only 상태 |
| `src/core/section_index.py` | 불변 빌드 메시의 최대 크기를 FaceZIndex에서 한 번 계산 |
| `src/core/sections.py` | 선택적 크기 전달, 잘못된 크기 거부, WindingLimit 초기 예외 안전 처리 |
| `src/ui/app.py` | 세 검사 집계와 작은 세부 표시, 재사용 크기 전달, 이전 버전 결과 재평가 안내, 요약 표 숫자 자료형 정리 |
| `src/core/reproducibility.py` | 버전 2.6 |
| `tests/test_layers_26.py` | 후보 보존·작은 실제 성분·미확정·실패·성능 경로·NIST의 신규 16개 검사 |
| `tests/test_ui_review.py` | 이전 버전 결과와 NIST 작은 지지/한 층 세부 화면의 신규 2개 검사 |
| `tests/test_layers_24.py` | 버전 기대값만 2.6으로 변경 |

‘전체 성분’ 판별에서 선폭은 내부 오프셋 소실, 지지·한 층은 참조 영역과 면적 교차가 없는 조건을 각각 사용한다.
DE-9IM 내부 교차 차원이 2인지를 검사하므로 점·선 접촉을 면적 지지로 취급하지 않는다.
기존 `unsupported_islands`는 종전의 비접촉 성분 수를 유지하며 새 전체 성분 플래그와 같은 정의가 아니다.
알 수 없는 이웃 범위는 기존 comparison_scope 기준으로 먼저 제외한다. 계산 실패나 재료 미확인은 통과가 아니다.

개별 후보 기록은 면적순 50개까지이며, 지도 오버레이와 전체 합계·개수는 그 제한으로 잘리지 않는다.
표시 하한은 검증된 제조 한계가 아니다. 우선 경고 층 감소를 오검출 감소나 정확도 향상으로 직접 보고하지 않는다.

기존 3D 측정·점수·프로필·Cura 보정식과 계수는 변경하지 않았다. STEP 직접 입력, 실제 툴패스, 새 AI 모델도 추가하지 않았다.
단면 기하와 총 후보 면적은 유지했지만 **지지·한 층 기본 면적 필드의 의미는 우선 검토 면적으로 변경**되었다.
JSON 이용자는 README의 후보 총합 필드로 이전 값을 대조해야 한다. 식별자도 fdm_layer_review_v3로 올렸다.

리뷰의 처리 시간은 환경과 작업 범위가 다르므로 그대로 성능 보장으로 쓰지 않았다.
단면 1장과 여러 층의 지표 검사, 부품 크기가 다른 반복 핀 사례를 같은 기준으로 비교하지 않는다.
원자료·외부 모델의 결과 대조와 실행 한계는 VALIDATION.md를 따른다.

기술 근거: [Shapely relate_pattern](https://shapely.readthedocs.io/en/2.1.2/reference/shapely.relate_pattern.html),
[STRtree](https://shapely.readthedocs.io/en/2.1.2/strtree.html).
