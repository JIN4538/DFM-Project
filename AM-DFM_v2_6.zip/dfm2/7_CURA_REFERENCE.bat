@echo off
chcp 65001 > nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
title AM-DFM  -  Reference data : Analyze Cura measurements
echo ==================================================
echo   Reference data : Analyze measurements.csv
echo.
echo   Analyze the preserved 24-condition reference data.
echo   Save a new analysis JSON without changing the CSV.
echo ==================================================
echo.

set "CONDA_BAT="
if exist "%USERPROFILE%\anaconda3\Scripts\activate.bat" set "CONDA_BAT=%USERPROFILE%\anaconda3\Scripts\activate.bat"
if exist "%USERPROFILE%\miniconda3\Scripts\activate.bat" set "CONDA_BAT=%USERPROFILE%\miniconda3\Scripts\activate.bat"
if exist "%LOCALAPPDATA%\anaconda3\Scripts\activate.bat" set "CONDA_BAT=%LOCALAPPDATA%\anaconda3\Scripts\activate.bat"
if exist "%LOCALAPPDATA%\miniconda3\Scripts\activate.bat" set "CONDA_BAT=%LOCALAPPDATA%\miniconda3\Scripts\activate.bat"
if exist "C:\ProgramData\anaconda3\Scripts\activate.bat" set "CONDA_BAT=C:\ProgramData\anaconda3\Scripts\activate.bat"
if exist "C:\ProgramData\miniconda3\Scripts\activate.bat" set "CONDA_BAT=C:\ProgramData\miniconda3\Scripts\activate.bat"
if exist "C:\Anaconda3\Scripts\activate.bat" set "CONDA_BAT=C:\Anaconda3\Scripts\activate.bat"

if not defined CONDA_BAT (
    echo [ERROR] Anaconda / Miniconda not found.
    echo Please run this from Anaconda Prompt instead.
    pause
    exit /b 1
)
call "%CONDA_BAT%" dfm
if errorlevel 1 (
    echo [ERROR] Could not activate conda environment "dfm".
    pause
    exit /b 1
)

python cura_check.py analyze --csv cura_run/measurements.csv
if errorlevel 1 exit /b 1
echo.
pause
