"""뮤테이션 테스팅 — 검증 하네스 자체를 검증한다

지금까지 두 번, 검증을 통과한 상태에서 결함이 남아 있었다.

  1차 : 19개 통과 상태에서 열린 메시·법선 반전 메시가 A등급을 받았고,
        하드 게이트가 백분위수를 써서 일부만 얇은 부품을 통과시켰다.
  2차 : 29개 통과 상태에서 면적 가중 표본 추출이 얇은 특징을 놓쳤다.

두 경우 모두 '시험이 그 영역을 건드리지 않았다'는 것이 원인이었다.
그렇다면 다음 사각지대는 어디인가? 이를 알아내는 표준적 방법이
뮤테이션 테스팅이다.

원리
----
코드에 일부러 결함(mutant)을 심고 검증을 돌린다.

  검증이 실패하면  -> 그 결함을 잡아낼 수 있다는 뜻 (mutant killed)
  검증이 통과하면  -> 그 영역이 시험되지 않고 있다는 뜻 (mutant survived)

살아남은 mutant 하나하나가 검증의 구멍이다. 통과율이 아니라
'죽인 비율(mutation score)'이 검증의 실제 강도를 나타낸다.

사용법
------
    python mutation_test.py            # 전체 실행
    python mutation_test.py --quick    # 대표 항목만
"""

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.abspath(__file__))

# (파일, 원본 문자열, 바꿀 문자열, 설명)
# 각 항목은 '이런 실수를 했다면 검증이 잡아내는가?' 라는 질문이다.
MUTANTS = [
    # ── 오버행 판정 ──
    ('src/core/geometry_analyzer.py',
     'needs = is_down & (inclination < critical_angle - EPS)',
     'needs = is_down & (inclination <= critical_angle + EPS)',
     '임계각 경계 부등호를 뒤집는다 (45도 면이 반대로 판정)'),

    ('src/core/geometry_analyzer.py',
     'is_down = dots < -EPS',
     'is_down = dots <= EPS',
     '수직벽을 다시 오버행에 포함시킨다 (v1 의 결함)'),

    ('src/core/geometry_analyzer.py',
     'needs = needs & ~on_plate',
     'needs = needs',
     '빌드 플레이트 접촉면 제외를 없앤다 (v1 의 결함)'),

    ('src/core/geometry_analyzer.py',
     'inclination = 180.0 - theta          # 하향면의 수평면 기준 경사각',
     'inclination = np.clip(90.0 - theta, 0, 90)  # v1 방식',
     'v1 의 clip 방식으로 되돌린다 (하향면 각도 정보 소실)'),

    # ── 지지구조물 부피 ──
    ('src/core/geometry_analyzer.py',
     'proj = areas * np.abs(normals[:, 2])',
     'proj = areas',
     '투영 면적 대신 면 넓이를 쓴다 (경사면 과대추정)'),

    ('src/core/geometry_analyzer.py',
     'support_volume = density * vol_term + wall * perim_term',
     'support_volume = density * vol_term',
     '둘레 항을 제거한다 (Cura 대조 전 상태로 회귀)'),

    # ── 벽두께 ──
    ('src/core/geometry_analyzer.py',
     'origins = centers - normals * eps',
     'origins = mesh.vertices[:len(centers)] - normals * eps',
     '면 중심 대신 정점을 기준점으로 쓴다 (v1 의 sqrt(3) 오차)'),

    ('src/core/geometry_analyzer.py',
     "idx_small = np.argsort(areas)[:max(1, n_rest - len(idx_uni))]",
     "idx_small = np.array([], dtype=int)",
     '작은 면 우선 표본을 제거한다 (얇은 특징 누락)'),

    # ── 하드 게이트 ──
    ('src/processes/additive.py',
     'if n_below >= 2:',
     'if n_below >= 10000:',
     '벽두께 게이트를 사실상 무력화한다'),

    ('src/core/geometry_analyzer.py',
     'fits = bool(len(mesh_bf.faces) and np.all(margins >= -1e-9))',
     'fits = True',
     '빌드 볼륨 게이트를 무력화한다'),

    ('src/processes/additive.py',
     'if problems:\n            return GateResult("메시 무결성", False,',
     'if False:\n            return GateResult("메시 무결성", False,',
     '메시 무결성 게이트를 무력화한다'),

    # ── 점수 함수 ──
    ('src/processes/additive.py',
     'if value >= threshold * good_factor:\n        return 100.0',
     'if value >= threshold * good_factor:\n        return 95.0',
     '점수 함수에 불연속을 만든다 (경계에서 5점 점프)'),

    ('src/processes/additive.py',
     'return max(0.0, 50.0 * value / threshold)',
     'return max(0.0, 60.0 * value / threshold)',
     '기준 미달 구간 점수를 부풀린다 (단조성은 유지)'),

    # ── 가중치 / 정규화 ──
    ('src/processes/additive.py',
     'r.weight = r.weight / active if (r.score is not None and active > 0) else 0.0',
     'r.weight = round(r.weight, 4) if (r.score is not None and active > 0) else 0.0',
     'N/A 가중치 재분배를 없앤다 (합이 1이 아니게 됨)'),

    # ── 좌표계 ──
    ('src/core/geometry_analyzer.py',
     "m.apply_transform(trimesh.geometry.align_vectors(b, [0, 0, 1]))",
     "pass  # 회전 생략",
     '빌드 좌표계 회전을 생략한다 (방향 무시)'),

    # ── 종횡비 ──
    ('src/core/geometry_analyzer.py',
     'width = float(min(ex[0], ex[1]))',
     'width = float(max(ex[0], ex[1]))',
     '종횡비 폭에 max 를 쓴다 (v1 의 결함)'),
]

QUICK = {0, 1, 2, 4, 5, 6, 8, 9, 14, 15}


def run_verify(workdir, timeout=600):
    try:
        p = subprocess.run([sys.executable, 'verify.py'], cwd=workdir,
                           capture_output=True, text=True, timeout=timeout)
        if p.returncode != 0:
            return p.returncode, p.stdout + p.stderr
        q = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_review.py'],
                           cwd=workdir, capture_output=True, text=True, timeout=timeout)
        return q.returncode, p.stdout + q.stdout + q.stderr
    except subprocess.TimeoutExpired:
        return -1, '(시간 초과)'
    except Exception as e:
        return -2, f'({e})'


def failed_names(out):
    return [ln.strip()[6:].strip() for ln in out.splitlines()
            if ln.strip().startswith('FAIL ')]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    args = ap.parse_args()

    targets = [(i, m) for i, m in enumerate(MUTANTS)
               if (not args.quick) or i in QUICK]

    print("=" * 78)
    print("뮤테이션 테스팅 — 일부러 결함을 심고 검증이 잡아내는지 본다")
    print("=" * 78)
    print(f"  결함 {len(targets)}개를 하나씩 심어 verify.py 를 실행한다.")
    print("  검증이 실패해야 정상(결함 탐지). 통과하면 그 영역은 시험되지 않고 있다.")
    print()

    baseline_rc, baseline_out = run_verify(ROOT)
    if baseline_rc != 0:
        print('원본 검증이 실패했습니다. 뮤테이션 점수를 계산하지 않습니다.')
        print(baseline_out[-3000:])
        return 2
    killed, survived, broken = [], [], []
    t0 = time.time()

    for n, (i, (relpath, old, new, desc)) in enumerate(targets, 1):
        with tempfile.TemporaryDirectory() as td:
            work = os.path.join(td, 'proj')
            shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns(
                '__pycache__', '*.pyc', 'cura_run', 'data', '.git'))
            fp = os.path.join(work, relpath)
            src = open(fp, encoding='utf-8').read()
            if old not in src:
                print(f"  [{n:2d}/{len(targets)}] SKIP  {desc}")
                print(f"           대상 코드를 찾지 못했다: {relpath}")
                broken.append(desc)
                continue
            open(fp, 'w', encoding='utf-8').write(src.replace(old, new, 1))

            rc, out = run_verify(work)
            fails = failed_names(out)
            if rc < 0:
                print(f'  실행 미완료: {desc} ({out})')
                broken.append(desc)
                continue
            if rc == 0:
                print(f"  [{n:2d}/{len(targets)}] 생존  {desc}")
                print(f"           검증이 통과했다. 이 결함을 잡는 시험이 없다.")
                survived.append(desc)
            else:
                shown = ', '.join(f[:34] for f in fails[:3]) or '(실행 실패)'
                print(f"  [{n:2d}/{len(targets)}] 제거  {desc}")
                print(f"           탐지: {shown}" + (f" 외 {len(fails)-3}건" if len(fails) > 3 else ""))
                killed.append((desc, fails))

    total = len(killed) + len(survived)
    score = len(killed) / total * 100 if total else 0.0
    print()
    print("=" * 78)
    print(f"뮤테이션 점수: {len(killed)} / {total} = {score:.1f}%   ({time.time()-t0:.0f}초)")
    print("=" * 78)
    if survived:
        print("\n살아남은 결함:")
        for d in survived:
            print(f"  · {d}")
        print()
        print("  살아남았다고 곧바로 사각지대인 것은 아니다. 두 경우를 구분해야 한다.")
        print()
        print("    (가) 진짜 사각지대  : 결함이 출력을 바꾸는데 시험이 못 잡았다.")
        print("                          -> 대응하는 시험을 추가해야 한다.")
        print("    (나) 동등 변이      : 결함을 심어도 출력이 바뀌지 않는다.")
        print("                          방어가 이중으로 걸려 있거나 해당 분기가")
        print("                          실제로 도달하지 않는 경우다.")
        print("                          -> 시험을 추가할 수 없고, 추가할 필요도 없다.")
        print()
        print("  구분 방법: 결함을 심은 상태와 원본에서 같은 입력의 출력을 직접 비교한다.")
        print("  출력이 동일하면 (나)이며, 뮤테이션 점수 계산에서 제외하는 것이 표준이다.")
    else:
        print("\n모든 결함을 탐지했다. 다만 이는 '심은 결함에 한해' 그렇다는 뜻이다.")
        print("결함 목록 자체가 상상의 산물이므로, 목록에 없는 유형은 여전히 미지수다.")
    if broken:
        print("\n적용하지 못한 항목 (코드가 바뀌어 문자열 불일치):")
        for d in broken:
            print(f"  · {d}")
    return 2 if broken else (0 if not survived else 1)


if __name__ == '__main__':
    sys.exit(main())
