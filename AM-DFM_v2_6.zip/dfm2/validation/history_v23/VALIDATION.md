# v2.3 실행 검증 기록

검증일: 2026-09-09. 환경: Linux / Python 3.12.14.
직접 의존성은 `requirements-tested.txt`의 버전으로 실행했다. 비교 기준은 직전 전달본 v2.2이다.

## 자동 검사

| 검사 | 결과 | 확인 범위 |
|---|---|---|
| `verify.py` | **55/55 통과** | 기존 형상·규칙·방향 비교 기준 |
| 회귀·화면 테스트 | **90/90 통과**, 실패 0, 오류 0, 건너뜀 0 | 기존 65개 + 신규 25개 |
| 외부 STL 10종의 원본·정리 후보 | **20회 평가 완료** | 진단·상태·점수·원본 보존 기록 |
| 실제 GB 메시의 Streamlit AppTest | 원본/정리 후보 각각 예외 0 | 부분 분석, 3D 그림 데이터, 외곽 치수, 부피 보류 표시 |
| GB의 Cura 예측표 내보내기 | 예상대로 거부, 출력 폴더 미게시 | 입력 문제에서 잘못된 형상 항을 내보내지 않음 |
| Cura 원자료 무결성 | **29개 파일 모두 바이트 일치** | 사용자 첨부 `dfm2.zip`의 `cura_run`과 대조 |

145개 자동 검사 항목 통과를 실물 제조 정확도 100%나 코드 커버리지로 해석하지 않는다.
외부 STL 20회는 원본 10종을 두 조건으로 실행한 것이며 독립 형상 20종이 아니다.
기존 T28은 표시 문자열을 ‘불가’에서 ‘프로필 미충족’으로 변경했지만, 점수 미산출과 `blocked` 상태 검사를 유지했다.

신규 검사는 열린 경계와 비다양체 구분, 입력 오류의 부분 분석 제한, 원본 비변경,
구멍·공동·작은 부품 보존, 반대 방향 중복면 보존, cm 입력 후보의 mm 내보내기,
0.2mm 평판과 0.3mm 핀 검출, 미확증 두께·근접 교차·재측정 실패의 보류, 상태 변경 후 과거 결과 차단을 다룬다.

기본 +Z / FDM 샘플 결과는 Good 100.0(A), Moderate 85.2(B), Bad 58.9(F)로 유지됐다.

## 외부 모델 결과

공통 조건: FDM, 파일 좌표 mm 가정, +Z, 장비 250×250×250mm, 기본 옵션.
각 결과는 해당 조건과 코드에서의 소프트웨어 판정이며 실제 출력 정답 라벨이 아니다.

| 모델 | v2.2 원본 | v2.3 원본 | v2.3 정리 후보 |
|---|---|---|---|
| GB.stl | 입력 오류 | 입력 검토 / 부분 분석 | 입력 검토 / 부분 분석 |
| 3DBenchy.stl | 입력 오류 | 입력 검토 / 부분 분석 | 입력 검토 / 부분 분석 |
| y-belt-holder.stl | 프로필 미충족 | 벽두께 확인 / 판정 보류 | 벽두께 확인 / 판정 보류 |
| y-motor-holder.stl | 판정 보류 | 벽두께 확인 / 판정 보류 | 벽두께 확인 / 판정 보류 |
| x-carriage.stl | 프로필 미충족 | 벽두께 확인 / 판정 보류 | 벽두께 확인 / 판정 보류 |
| extruder-cover.stl | 입력 오류 | 입력 검토 / 부분 분석 | 입력 검토 / 부분 분석 |
| z-axis-top.stl | 프로필 미충족 | 입력 검토 / 부분 분석 | 입력 검토 / 부분 분석 |
| LCD-knob.stl | 프로필 미충족 | 벽두께 확인 / 판정 보류 | 벽두께 확인 / 판정 보류 |
| y-rod-holder.stl | 93.5(A) | 93.5(A) | 93.5(A) |
| z-screw-cover.stl | 프로필 미충족 | 벽두께 확인 / 판정 보류 | 벽두께 확인 / 판정 보류 |

GB 원본은 열린 경계 0 / 비다양체 모서리 1,274 / 중복면 54 / 퇴화면 174이다.
정리 후보는 열린 경계 12 / 비다양체 모서리 1,142 / 중복면 23 / 퇴화면 0이다.
원본·후보의 외곽 좌표 최대 차이는 0mm였지만 솔리드 검사는 둘 다 통과하지 못했다.
따라서 종합 점수는 없으며 부분 분석만 제공하는 것이 예상 결과다.

`z-axis-top`은 원본의 퇴화면 2개를 새로 탐지해 입력 검토로 바뀌었다. 후보에는 열린 경계 6개가 남는다.
정리 후 모든 파일이 통과하도록 검사 조건을 완화하지 않았다.
Prusa 부품 8종과 3DBenchy의 출처·정확한 파일 해시는 `validation/external_model_sources.json`에 있다.
다른 버전·다른 해상도·다른 단위로 저장된 파일이 같은 결과를 낸다고 보장하지 않는다.

GB의 원본+정리 후보 로드·진단·평가는 이 환경에서 약 6.0초였다.
단일 실행 관측값이며 화면 업로드·브라우저 렌더링 시간을 포함하지 않는다.
실제 GB 메시를 넣은 AppTest에서 약 29.7MB의 Plotly JSON이 생성됐다.
대용량 3D의 브라우저 응답성과 GPU 메모리는 추가 확인이 필요하다.

## Cura 대조와 과거 수치 보존

과거 4형상×6방향=24조건을 다시 읽었다. 지름 기록이 없어 필라멘트 지름 1.75mm를 가정했다.
서포트 OFF/ON 길이 차이로 추가 재료 부피를 환산한 대조이며, 이번에 Cura를 다시 슬라이싱하지는 않았다.

| 지표 | 값 |
|---|---:|
| 과거 CSV 저장 예측값 R² | **0.9784086107** |
| 과거 예측 MAE | 943.9666mm³ |
| 과거 예측 RMSE | 1916.6042mm³ |
| 0-0 조건 6개 제외, 18행 R² | 0.9740608097 |
| 현재 엔진 고정 계수 예측 R² | 0.9784319095 |
| 현재 형상 항의 2항 계수 재적합 R² | 0.9784327042 |
| 현재 형상 항, 부품 전체 제외 통합 Q² | 0.9775843686 |

보고서의 **R²=0.978을 유지**했고 원자료·서포트 계수·가중치를 변경하지 않았다.
현재 재계산을 기록이 부족한 과거 실행 환경의 완전한 복원으로 설명하지 않는다.
부품 제외 검증도 고정된 2항 공식의 계수만 다시 맞춘 것이며 공식 선택까지 독립적인 외부 잠금 시험은 아니다.
NIST의 일부 방향에 큰 잔차가 남는다. 높은 전체 R²를 벽두께·종합 등급·실제 출력 품질의 정확도로 확대하지 않는다.

## 재현 명령과 증거 파일

```bash
python verify.py
python -m unittest discover -s tests -v
python cura_check.py analyze --csv cura_run/measurements.csv
python cura_check.py analyze --csv cura_run/measurements.csv --recompute-terms
python cura_check.py why --stl GB.stl --unit mm --report gb_review_new.json
python audit_models.py GB.stl another.stl --unit mm --out audit_new.json
```

GB와 공개 STL은 원래 파일을 별도로 준비한다. 파일 이름만으로 동일 형상이라고 가정하지 말고 기록된 SHA-256을 대조한다.
명령행 결과는 기존 파일을 덮어쓰지 않으므로 재실행할 때 새 출력 이름을 사용한다.

| 파일 | 내용 |
|---|---|
| `validation/v23_verify.log` | 55항목 실행 기록 |
| `validation/v23_tests.log`, `validation/v23_test_summary.json` | 90개 테스트 이름·결과·집계 |
| `validation/v23_real_models.json`, `validation/v23_real_models.log` | 외부 STL 원본·후보 20회 전체 결과, 변경 기록 |
| `validation/v23_gb_app.json`, `validation/v23_gb_app.log` | 실제 GB 메시의 화면 실행·그림 데이터 생성 확인 |
| `validation/v23_cli_guard.json`, `validation/v23_cli_guard.log` | GB 예측표 내보내기 거부와 출력 미게시 |
| `validation/v23_sample_scores.json` | 기본 샘플 점수 |
| `validation/cura_original_v23.json`, `validation/cura_original_v23.log` | 과거 저장 예측값 대조 |
| `validation/cura_current_v23.json`, `validation/cura_current_v23.log` | 현재 형상 항·고정 예측·회귀 |
| `validation/raw_data_integrity_v23.json` | 원자료 29개 파일의 바이트 일치 |
| `validation/external_model_sources.json` | 외부 파일 출처·해시 |
| `SOURCE_MANIFEST.json` | 배포 파일 해시 |

분석 JSON의 실행 코드 해시가 현재 코드와 같은지 확인했다.
이전 검토 기록은 `validation/history_v21/`, `validation/history_v22/`에 보존했다.

## 확인하지 못한 범위와 남은 위험

- 실물 출력, Cura 프로젝트/G-code와 수기 길이 대조, 실제 Cura 재슬라이싱은 하지 않았다.
- Windows 배치를 직접 실행하지 않았다. Streamlit AppTest는 업로드 위젯이나 실제 브라우저 픽셀 렌더링의 종단 간 검증이 아니다. 실제 GB는 샘플 입력 훅으로 공급했다.
- 브라우저 자동 검증용 실행 파일 다운로드가 시간 초과해 픽셀 검증을 완료하지 못했다.
- 벽두께 재측정의 코사인·공간 범위·예산은 휴리스틱이다. 조밀한 테셀레이션·경사진 실제 얇은 면에서 보류 또는 미검출 가능성이 남는다.
- 단일 셸 자기교차 전수 검사와 일반적인 메시 복구를 제공하지 않는다. 부분 분석은 입력 형상 복구가 아니다.
- 로그에 Streamlit `use_container_width` 안내와 일부 퇴화 형상의 Trimesh 수치 경고가 남는다. 검사 실패·오류는 없었으며 정의되지 않은 적분값을 실제 부피로 확정하지 않는다.
- 다른 의존성 버전·대용량 산업용 형상·다중 사용자 성능·전체 뮤테이션 테스트는 이번 확인 범위가 아니다.
