from pathlib import Path
import sys,time,json
import numpy as np,trimesh
root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from src.core.layer_review import inspect_layers
from src.core.sections import section_mesh
from src.core.reproducibility import runtime_record,json_ready,save_new_json

def pin_array(n=900):
    pin=trimesh.creation.cylinder(radius=.3,height=2,sections=16)
    copies=[]; side=int(np.ceil(np.sqrt(n)))
    for i in range(n):
        p=pin.copy();p.apply_translation([(i%side)*1.5,(i//side)*1.5,0]);copies.append(p)
    return trimesh.util.concatenate(copies)

def make_cases():
    sphere=trimesh.creation.icosphere(subdivisions=4,radius=25)
    damaged=sphere.copy();keep=np.ones(len(sphere.faces),dtype=bool)
    keep[np.random.default_rng(20260909).choice(len(keep),30,replace=False)]=False;damaged.update_faces(keep)
    good=trimesh.creation.box([20,20,50]);good.apply_translation([80,0,0])
    a=trimesh.creation.box([4,3,2]);b=a.copy();b.invert()
    return {'sphere_r25_sub4':sphere,'pin_array_900':pin_array(),
            'damaged_sphere_and_separate_box':trimesh.util.concatenate([damaged,good]),
            'opposite_duplicate_shells':trimesh.util.concatenate([a,b]),
            'wall_0p3':trimesh.creation.box([20,.3,2]),
            'tiny_pin_0p03':trimesh.creation.cylinder(radius=.015,height=2,sections=32)}
if __name__=='__main__':
    out={'runtime':runtime_record(),'cases':[],'note':'Deterministic reproduction fixtures; review did not provide its script or exact removed face indices.'}
    for name,m in make_cases().items():
        start=time.perf_counter();r=inspect_layers(m)
        row=dict(name=name,faces=len(m.faces),seconds=time.perf_counter()-start,result=r)
        out['cases'].append(row)
        print(name,r['status'],r['complete_layers'],[(c['name'],c['status'],c.get('sum_mm2')) for c in r['checks']],flush=True)
    save_new_json(sys.argv[2],out)
