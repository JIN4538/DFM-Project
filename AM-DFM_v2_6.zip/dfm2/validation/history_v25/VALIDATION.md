# v2.5 검증 기록

검증일 2026-09-09. Linux / Python 3.12.14. 코드 해시 `0b48bc9fdc24ccd71e03a3b39f79713b1e07864a48b05782032b57b8bd0f908c`.
NumPy 2.3.5, SciPy 1.17.0, trimesh 5.1.0, rtree 1.4.1, manifold3d 3.5.3,
Streamlit 1.63.0, Plotly 7.0.0, pandas 2.2.3, Shapely 2.1.2.

## 최종 검사

| 검사 | 결과 | 실행 증거 |
|---|---|---|
| 기존 기본 검증 | 55/55 통과 | `validation/v25_verify.log` |
| 회귀·화면 검사 | 149/149 통과, 실패·오류·생략 0 | `validation/v25_tests.log`, `v25_test_summary.json` |
| 외부 형상 | 16개 원본·정리 후보 모두 전 층 계산 | `validation/v25_real_models.json` |
| GB 실제 메시 화면 | 원본·정리 후보 212층, 슬라이더·작은 세부·지지·한 층 표시, 예외 0 | `validation/v25_gb_app.json` |
| 기존 외부 3D 결과 보존 | 16개 원본·정리 후보의 기존 필드 모두 일치 | `validation/v25_legacy_comparison.json` |
| 기존 샘플 점수 | Good 100.0(A), Moderate 85.2(B), Bad 58.9(F) | `validation/v25_sample_scores.json` |
| Cura 저장 예측 | R²=0.9784086106593225 유지 | `validation/cura_original_v25.json` |
| 현재 3D 항 재계산 | R²=0.978431909544024 | `validation/cura_current_v25.json` |
| 원자료 보존 | cura_run 29개 파일 모두 원본 dfm2.zip과 바이트 일치 | `validation/raw_data_integrity_v25.json` |

기본 검증과 회귀 검사에는 서로 겹치는 목적이 있으므로 이를 독립적인 실제 제조 실험 횟수로 합산하지 않습니다.
16개는 GB 1개, Benchy 1개, Prusa 부품 14개이며 무작위 표본이 아닙니다.

## 리뷰 지적 독립 재현

재현 스크립트는 `validation/reproduce_review.py`입니다. 구의 면 삭제는 난수 시드 20260909로 고정했습니다.
리뷰의 원 시험 스크립트가 없으므로 원문 수치의 동일 재현이 아니라 같은 결함 종류의 독립 재현입니다.
기본 +Z, h=0.2mm, 선폭 0.4mm, 경사 45°를 사용합니다.

| 형상 | v2.4 상태 / 전체 확정 층 | v2.5 상태 / 전체 확정 층 | v2.4 초 | v2.5 초 |
|---|---|---|---:|---:|
| sphere_r25_sub4 | complete / 250 | complete / 250 | 1.711 | 1.260 |
| pin_array_900 | unavailable / 0 | complete / 10 | 17.080 | 24.315 |
| damaged_sphere_and_separate_box | partial / 104 | partial / 104 | 2.171 | 2.505 |
| opposite_duplicate_shells | unavailable / 10 | unavailable / 0 | 0.013 | 0.023 |
| wall_0p3 | complete / 10 | complete / 10 | 0.014 | 0.015 |
| tiny_pin_0p03 | complete / 10 | complete / 10 | 0.031 | 0.023 |

시간은 같은 환경에서 각각 1회 측정한 값입니다. 구는 약 1.36배 향상되었고 10배~50배 개선은 확인하지 않았습니다.
900개 핀은 v2.4가 계산 한도로 실패하는 반면 v2.5는 전체 검사를 수행하므로 두 시간을 동일 작업의 속도비로 비교할 수 없습니다.
손상 구와 분리 박스도 추가 검사를 수행하므로 비용이 증가했습니다.

- 900핀 첫 층: 종전 내부 판별 비용 25,920,000회에 해당하던 입력에서 실제 공간 후보 27,000회. 재료 성분 900개와 이론적 다각형 핀 면적 일치.
- 구의 선폭 잔여 합 약 0.000772229mm²: 삭제하지 않고 작은 세부로 보존. 우선 검토 면적은 0. 지지 위험은 별도 유지.
- 손상 구 + 분리 박스: 전체 확정은 104/250=41.6% 유지. 미확정 146개 층에서도 박스의 닫힌 성분 검사. 전체 부피는 미산출.
- 지름 0.03mm 핀: 각 층 면적 약 0.000702325mm²로 표시 하한 0.0016mm²보다 작지만 전체 성분 소실로 검출 유지.
- 반대 중복 껍질: 모든 층 재료 상쇄 시 모든 위험 검사 미확정과 분석 불가 사유 기록.

## 외부 파일의 결과

모든 입력은 mm, +Z, FDM, 장비 250×250×250mm, 단면 h=0.2mm·선폭 0.4mm·경사 45°입니다.
원본과 정리 후보는 동일 부품의 두 분석이며 독립 모델 32개로 세지 않습니다.
입력 파일 해시가 평가 전후 동일함을 확인했습니다.

| 파일 | 원본 전체 확정 / 요청 층 | 정리 후보 | 3D 상태 | 3D 점수 |
|---|---:|---|---|---:|
| GB.stl | 212 / 212 | complete | invalid_input | 미산출 |
| 3DBenchy.stl | 240 / 240 | complete | invalid_input | 미산출 |
| y-belt-holder.stl | 90 / 90 | complete | indeterminate | 미산출 |
| y-motor-holder.stl | 95 / 95 | complete | indeterminate | 미산출 |
| x-carriage.stl | 75 / 75 | complete | indeterminate | 미산출 |
| extruder-cover.stl | 115 / 115 | complete | invalid_input | 미산출 |
| z-axis-top.stl | 80 / 80 | complete | invalid_input | 미산출 |
| LCD-knob.stl | 40 / 40 | complete | indeterminate | 미산출 |
| y-rod-holder.stl | 50 / 50 | complete | eligible | 93.5 |
| z-screw-cover.stl | 25 / 25 | complete | indeterminate | 미산출 |
| x-end-idler.stl | 290 / 290 | complete | blocked | 미산출 |
| x-end-motor.stl | 290 / 290 | complete | blocked | 미산출 |
| Einsy-base.stl | 190 / 190 | complete | invalid_input | 미산출 |
| fs-cover.stl | 20 / 20 | complete | eligible | 85.7 |
| fan-shroud.stl | 100 / 100 | complete | indeterminate | 미산출 |
| extruder-body.stl | 100 / 100 | complete | indeterminate | 미산출 |

GB 원본의 기존 3D 점수는 계속 미산출입니다. 입력을 완벽한 솔리드로 복구했다는 주장이 아닙니다.
우선 선폭 검토는 139층 / 합계 23.986960mm²,
작은 세부 합계 1.183886mm²로 분리했습니다.
지지 검토 426.806998mm²와 한 층만 존재하는 영역 47.219002mm²는 유지됩니다.
합산 면적은 여러 층에서 더한 값이며 실제 서포트 재료 부피가 아닙니다.

GB 원본·정리 후보 2회 전체 평가 합산 46.090초. 장비·동시 작업에 따라 달라집니다.
GB 화면 검사는 AppTest 샘플 입력 경로에 실제 메시를 주입한 것으로 업로드 위젯 마우스 조작·브라우저 픽셀·GPU 검사는 아닙니다.
현재 GB 화면의 Plotly 데이터는 약 30MB이며 노트북 성능은 별도 확인해야 합니다.

## 재검증 범위와 한계

예상 단면적과 공동 구조를 아는 합성 형상, 실제 결함 주입, 작은 실제 특징,
인접 층의 미확정 영향, 후보 한도, 캐시 갱신, 전체 공기 층, 이전 결과 보존을 검사했습니다.
작은 세부의 표시 하한은 제조 실험으로 보정한 값이 아닙니다. 외부 16개 처리 완료도 제조 정확도나 인터넷 전체 성공률을 뜻하지 않습니다.
실제 Cura 재슬라이싱, 프린터 출력, Windows 배치와 노트북 브라우저 실행은 이번 환경에서 수행하지 않았습니다.
Cura의 과거 R²는 추가 재료량 대조값이며 새 단면 판정의 정확도가 아닙니다.

## 다시 실행하기

```bash
python -m pip install -r requirements-tested.txt
python verify.py
python -m unittest discover -s tests -v
python validation/reproduce_review.py . reproduction_new.json
python audit_models.py GB.stl another.stl --out audit_new.json
python cura_check.py analyze --csv cura_run/measurements.csv --out reference_new.json
python cura_check.py analyze --csv cura_run/measurements.csv --recompute-terms --out current_new.json
```

출력에는 새 파일명을 사용하세요. 외부 STL 출처·해시는 `validation/external_model_sources.json`에 있으며 STL 자체는 재배포하지 않습니다.
v2.4 문서와 검사 기록은 `validation/history_v24/`에 보존했습니다.
