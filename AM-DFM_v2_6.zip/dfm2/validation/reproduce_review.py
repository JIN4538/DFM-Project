"""Same inputs across versions; recorded results are not manufacturing labels."""
from pathlib import Path
import sys,time,cProfile,pstats
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
import numpy as np,trimesh
from src.core.layer_review import inspect_layers
from src.core.model_loader import load_model
from src.core.reproducibility import runtime_record,save_new_json,file_sha256
from src.processes.additive import AMRuleEngine

if __name__=='__main__':
    path=root/'cura_run/NIST_Test_Artifact_online__posZ.stl'
    nist=load_model(str(path))['mesh']
    sphere=trimesh.creation.icosphere(subdivisions=6,radius=25)
    results=[]
    for name,mesh in [('NIST_posZ',nist),('sphere_r25_sub6',sphere)]:
        t=time.perf_counter();result=inspect_layers(mesh);elapsed=time.perf_counter()-t
        results.append(dict(name=name,faces=len(mesh.faces),seconds=elapsed,result=result))
        print(name,round(elapsed,3),[(c['name'],c['status'],c.get('risk_layers'),c.get('sum_mm2'),c.get('detail_sum_mm2')) for c in result['checks']],flush=True)
    profile=cProfile.Profile();profile.enable();inspect_layers(sphere);profile.disable()
    stats=pstats.Stats(profile)
    rows=[dict(file=f,line=line,function=func,calls=value[1],self_seconds=value[2],cumulative_seconds=value[3])
          for (f,line,func),value in stats.stats.items() if func in ('hash_fallback','extents','difference','buffer','simple_ring')]
    t=time.perf_counter();legacy=AMRuleEngine().evaluate(sphere,layer_review_enabled=False);legacy_time=time.perf_counter()-t
    out=dict(runtime=runtime_record(),source_file=path.name,source_sha256=file_sha256(path),settings=dict(layer_height_mm=.2,line_width_mm=.4,critical_angle_deg=45),cases=results,
             profile=rows,legacy_only_sphere_seconds=legacy_time,legacy_status=legacy.evaluation_status,
             note='Fresh deterministic inputs, one timed execution each. A separate profiling execution adds overhead and is not the timed run. Raw geometry results are not physical print labels.')
    save_new_json(sys.argv[2],out)
    print('legacy-only sphere',round(legacy_time,3),'profile',rows,flush=True)
