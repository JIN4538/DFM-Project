@echo off
chcp 65001 > nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
title AM-DFM  -  Verification harness
echo ==============================================
echo   AM-DFM   Step 2 : Verification
echo ==============================================
echo.

set "CONDA_BAT="
if exist "%USERPROFILE%\anaconda3\Scripts\activate.bat" set "CONDA_BAT=%USERPROFILE%\anaconda3\Scripts\activate.bat"
if exist "%USERPROFILE%\miniconda3\Scripts\activate.bat" set "CONDA_BAT=%USERPROFILE%\miniconda3\Scripts\activate.bat"
if exist "%LOCALAPPDATA%\anaconda3\Scripts\activate.bat" set "CONDA_BAT=%LOCALAPPDATA%\anaconda3\Scripts\activate.bat"
if exist "%LOCALAPPDATA%\miniconda3\Scripts\activate.bat" set "CONDA_BAT=%LOCALAPPDATA%\miniconda3\Scripts\activate.bat"
if exist "C:\ProgramData\anaconda3\Scripts\activate.bat" set "CONDA_BAT=C:\ProgramData\anaconda3\Scripts\activate.bat"
if exist "C:\ProgramData\miniconda3\Scripts\activate.bat" set "CONDA_BAT=C:\ProgramData\miniconda3\Scripts\activate.bat"
if exist "C:\Anaconda3\Scripts\activate.bat" set "CONDA_BAT=C:\Anaconda3\Scripts\activate.bat"

if not defined CONDA_BAT (
    echo [ERROR] Anaconda / Miniconda not found.
    echo Please open Anaconda Prompt and run this file from there instead.
    echo.
    pause
    exit /b 1
)

call "%CONDA_BAT%" dfm
if errorlevel 1 (
    echo [ERROR] Could not activate conda environment "dfm".
    echo Check the environment name with:  conda env list
    echo.
    pause
    exit /b 1
)

python verify.py
if errorlevel 1 exit /b 1
python -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
echo.
echo ==============================================
echo   Expected result : all checks pass
echo   Keep this window - it is your slide.
echo ==============================================
pause
