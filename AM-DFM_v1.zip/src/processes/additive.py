"""적층제조(AM) 제조성 평가 규칙 엔진

ISO/ASTM 52910 기반 설계 지침을 규칙으로 구현합니다.
각 규칙은 평가 함수, 가중치, 합격 기준을 가집니다.

Reference:
- ISO/ASTM 52910: Additive manufacturing — Design — Required principles
- Oh, Y., Ko, H., Sprock, T., Bernstein, W.Z. and Kwon, S. (2021)
  "Part decomposition and evaluation based on standard design guidelines
   for additive manufacturability and assemblability", Additive Manufacturing, 37, 101702
"""

import trimesh
import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Callable
from enum import Enum

# 상위 모듈 import
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.core.geometry_analyzer import (
    compute_wall_thickness,
    compute_overhang_angles,
    compute_support_volume,
    compute_aspect_ratio,
    compute_build_volume_fit,
    compute_min_feature_size,
    compute_hole_analysis,
)


# ── 데이터 클래스 ──────────────────────────────────────────────

class ProcessType(Enum):
    FDM = "FDM"
    SLA = "SLA"
    SLS = "SLS"
    DMLS = "DMLS"


@dataclass
class RuleResult:
    """개별 규칙 평가 결과."""
    rule_name: str
    description: str
    passed: bool
    value: float
    threshold: float
    unit: str
    score: float  # 0~100
    details: str = ""
    problem_face_indices: list = field(default_factory=list)


@dataclass
class EvaluationResult:
    """전체 평가 결과."""
    rule_results: List[RuleResult] = field(default_factory=list)
    total_score: float = 0.0
    grade: str = "F"
    process_type: str = "FDM"
    build_direction: list = field(default_factory=lambda: [0, 0, 1])
    summary: str = ""
    improvement_suggestions: List[str] = field(default_factory=list)


# ── 공정별 임계값 ────────────────────────────────────────────────

PROCESS_THRESHOLDS = {
    ProcessType.FDM: {
        'min_wall_thickness': 1.0,      # mm
        'overhang_critical_angle': 45.0, # 도
        'support_volume_ratio': 0.5,
        'aspect_ratio': 10.0,
        'min_feature_size': 0.8,        # mm (노즐 직경 기준)
        'horizontal_hole_diameter': 8.0,  # mm
    },
    ProcessType.SLA: {
        'min_wall_thickness': 0.5,
        'overhang_critical_angle': 30.0,
        'support_volume_ratio': 0.3,
        'aspect_ratio': 8.0,
        'min_feature_size': 0.3,
        'horizontal_hole_diameter': 5.0,
    },
    ProcessType.SLS: {
        'min_wall_thickness': 0.8,
        'overhang_critical_angle': 0.0,  # SLS는 지지구조 불필요
        'support_volume_ratio': 0.0,
        'aspect_ratio': 12.0,
        'min_feature_size': 0.5,
        'horizontal_hole_diameter': 10.0,
    },
    ProcessType.DMLS: {
        'min_wall_thickness': 0.3,
        'overhang_critical_angle': 45.0,
        'support_volume_ratio': 0.4,
        'aspect_ratio': 8.0,
        'min_feature_size': 0.2,
        'horizontal_hole_diameter': 6.0,
    },
}

# 규칙 가중치 (합 = 1.0)
RULE_WEIGHTS = {
    'min_wall_thickness': 0.20,
    'overhang_angle': 0.20,
    'support_volume_ratio': 0.15,
    'build_volume_fit': 0.10,
    'aspect_ratio': 0.10,
    'min_feature_size': 0.15,
    'horizontal_hole_diameter': 0.10,
}


# ── AM 규칙 기반 클래스 ──────────────────────────────────────────

class AMRuleBase:
    """적층제조 제조성 평가 규칙 엔진.

    ISO/ASTM 52910 기반 7개규칙으로 제조성을 평가하고,
    0~100점 점수와 A~F 등급을 산출합니다.

    Usage
    -----
    >>> engine = AMRuleBase()
    >>> result = engine.evaluate(mesh, process_type='FDM')
    >>> print(f"Score: {result.total_score}, Grade: {result.grade}")
    """

    def __init__(self):
        self.rules = self._define_rules()

    def _define_rules(self) -> dict:
        """평가 규칙 정의."""
        return {
            'min_wall_thickness': {
                'name': 'Min Wall Thickness (최소 벽두께)',
                'description': '부품의 최소 벽두께가 공정의 하한선 이상인지 검사',
                'unit': 'mm',
            },
            'overhang_angle': {
                'name': 'Overhang Angle (오버행 각도)',
                'description': '지지구조물이 필요한 오버hang 면의 비율 검사',
                'unit': '%',
            },
            'support_volume_ratio': {
                'name': 'Support Volume Ratio (지지구조물 부피 비율)',
                'description': '지지구조물 부피 / 부품 부피 비율 검사',
                'unit': 'ratio',
            },
            'build_volume_fit': {
                'name': 'Build Volume Fit (빌드 볼륨 적합성)',
                'description': '부품이 프린터 빌드 볼륨 내에 있는지 검사',
                'unit': 'bool',
            },
            'aspect_ratio': {
                'name': 'Aspect Ratio (종횡비)',
                'description': '빌드 방향 높이/너비 비율 검사',
                'unit': 'ratio',
            },
            'min_feature_size': {
                'name': 'Min Feature Size (최소 특징 크기)',
                'description': '가장 작은 특징(모서리 길이)이 공정 한계 이상인지 검사',
                'unit': 'mm',
            },
            'horizontal_hole_diameter': {
                'name': 'Horizontal Hole Dia. (수평 구멍 직경)',
                'description': '수평 방향 구멍이 지지구조 없이 인쇄 가능한 크기인지 검사',
                'unit': 'mm',
            },
        }

    def evaluate(self,
                 mesh: trimesh.Trimesh,
                 process_type: str = 'FDM',
                 build_direction: list = None,
                 printer_dims: list = None) -> EvaluationResult:
        """부품의 AM 제조성을 평가합니다.

        Parameters
        ----------
        mesh : trimesh.Trimesh
            평가할 3D 메시
        process_type : str
            공정 유형 ('FDM', 'SLA', 'SLS', 'DMLS')
        build_direction : list
            적층 방향 벡터 (기본: [0,0,1])
        printer_dims : list
            프린터 빌드 볼륨 [X, Y, Z] mm

        Returns
        -------
        EvaluationResult
        """
        if build_direction is None:
            build_direction = [0.0, 0.0, 1.0]
        if printer_dims is None:
            printer_dims = [250.0, 250.0, 250.0]

        # 공정 유형 매핑
        try:
            ptype = ProcessType[process_type.upper()]
        except KeyError:
            ptype = ProcessType.FDM

        thresholds = PROCESS_THRESHOLDS[ptype]
        build_dir = np.array(build_direction, dtype=float)

        # ── 형상 분석 실행 ──
        wall_thick = compute_wall_thickness(mesh)
        overhang = compute_overhang_angles(mesh, build_dir)
        support = compute_support_volume(mesh, build_dir)
        aspect = compute_aspect_ratio(mesh)
        vol_fit = compute_build_volume_fit(mesh, printer_dims)
        min_feat = compute_min_feature_size(mesh)
        hole_info = compute_hole_analysis(mesh, build_dir)

        # ── 규칙별 평가 ──
        rule_results = []

        # 1. 최소 벽두께
        r1 = self._evaluate_wall_thickness(wall_thick, thresholds)
        rule_results.append(r1)

        # 2. 오버행 각도
        r2 = self._evaluate_overhang(overhang, thresholds)
        rule_results.append(r2)

        # 3. 지지구조물 부피 비율
        r3 = self._evaluate_support_ratio(support, thresholds)
        rule_results.append(r3)

        # 4. 빌드 볼륨 적합성
        r4 = self._evaluate_build_volume(vol_fit, printer_dims)
        rule_results.append(r4)

        # 5. 종횡비
        r5 = self._evaluate_aspect_ratio(aspect, thresholds)
        rule_results.append(r5)

        # 6. 최소 특징 크기
        r6 = self._evaluate_min_feature(min_feat, thresholds)
        rule_results.append(r6)

        # 7. 수평 구멍 직경
        r7 = self._evaluate_horizontal_hole(hole_info, thresholds)
        rule_results.append(r7)

        # ── 종합 점수 산출 ──
        total_score = self._compute_total_score(rule_results)
        grade = self._compute_grade(total_score)
        summary = self._generate_summary(rule_results, total_score, grade)
        suggestions = self._generate_suggestions(rule_results, ptype)

        return EvaluationResult(
            rule_results=rule_results,
            total_score=total_score,
            grade=grade,
            process_type=process_type.upper(),
            build_direction=build_direction,
            summary=summary,
            improvement_suggestions=suggestions,
        )

    # ── 개별 규칙 평가 메서드 ──

    def _evaluate_wall_thickness(self, analysis: dict,
                                   thresholds: dict) -> RuleResult:
        min_thick = analysis['min_thickness']
        threshold = thresholds['min_wall_thickness']
        passed = min_thick >= threshold

        # 점수: threshold에 비례. threshold의 2배 이상이면 100점
        if min_thick >= threshold * 2:
            score = 100.0
        elif min_thick >= threshold:
            score = 50.0 + 50.0 * (min_thick - threshold) / threshold
        else:
            score = max(0, 50.0 * (min_thick / threshold))

        return RuleResult(
            rule_name='min_wall_thickness',
            description=self.rules['min_wall_thickness']['name'],
            passed=passed,
            value=round(min_thick, 3),
            threshold=threshold,
            unit='mm',
            score=round(score, 1),
            details=f"최소 벽두께: {min_thick:.2f}mm / 기준: {threshold}mm "
                    f"| 얇은 벽 점: {len(analysis['thin_point_indices'])}개",
            problem_face_indices=analysis['thin_point_indices'][:50],
        )

    def _evaluate_overhang(self, analysis: dict,
                             thresholds: dict) -> RuleResult:
        support_ratio = analysis['support_ratio']
        critical_angle = thresholds['overhang_critical_angle']

        # SLS는 지지구조 불필요 → 자동 합격
        if critical_angle == 0.0:
            return RuleResult(
                rule_name='overhang_angle',
                description=self.rules['overhang_angle']['name'],
                passed=True, value=0.0, threshold=0.0,
                unit='%', score=100.0,
                details="SLS 공정은 지지구조물이 필요하지 않습니다."
            )

        # 합격 기준: 지지구조가 필요한 면적이 30% 미만
        OVERHANG_AREA_LIMIT = 0.30
        passed = support_ratio < OVERHANG_AREA_LIMIT

        if support_ratio < 0.10:
            score = 100.0
        elif support_ratio < OVERHANG_AREA_LIMIT:
            score = 100.0 * (1.0 - support_ratio / OVERHANG_AREA_LIMIT * 0.5)
        else:
            score = max(0, 50.0 * (1.0 - support_ratio))

        return RuleResult(
            rule_name='overhang_angle',
            description=self.rules['overhang_angle']['name'],
            passed=passed,
            value=round(support_ratio * 100, 1),
            threshold=OVERHANG_AREA_LIMIT * 100,
            unit='%',
            score=round(score, 1),
            details=f"오버hang 면적 비율: {support_ratio*100:.1f}% "
                    f"({analysis['overhang_face_count']}면) / 임계각: {critical_angle}°",
            problem_face_indices=analysis['overhang_face_indices'][:100],
        )

    def _evaluate_support_ratio(self, analysis: dict,
                                   thresholds: dict) -> RuleResult:
        ratio = analysis['support_ratio']
        threshold = thresholds['support_volume_ratio']
        passed = ratio <= threshold

        if ratio <= 0:
            score = 100.0
        elif ratio <= threshold * 0.5:
            score = 100.0
        elif ratio <= threshold:
            score = 100.0 * (1.0 - ratio / (threshold * 2))
        else:
            score = max(0, 30.0 * (1.0 - ratio / (threshold * 3)))

        return RuleResult(
            rule_name='support_volume_ratio',
            description=self.rules['support_volume_ratio']['name'],
            passed=passed,
            value=round(ratio, 3),
            threshold=threshold,
            unit='ratio',
            score=round(score, 1),
            details=f"지지구조물 부비 비율: {ratio:.3f} / 기준: {threshold} "
                    f"| 부피: {analysis['support_volume']:.1f}mm³",
        )

    def _evaluate_build_volume(self, analysis: dict,
                                 printer_dims: list) -> RuleResult:
        fits = analysis['fits']
        passed = fits

        if fits:
            # 여유 공간이 클수록 점수 상승
            margins = analysis['margin']
            min_margin_ratio = min(m / p for m, p in
                                    zip(margins, printer_dims) if p > 0)
            score = min(100.0, 70.0 + min_margin_ratio * 30.0 * 100)
        else:
            score = 0.0

        return RuleResult(
            rule_name='build_volume_fit',
            description=self.rules['build_volume_fit']['name'],
            passed=passed,
            value=1.0 if fits else 0.0,
            threshold=1.0,
            unit='bool',
            score=round(score, 1),
            details=f"부품 크기: {analysis['part_size']} / "
                    f"프린터: {printer_dims} | 여유: {analysis['margin']}",
        )

    def _evaluate_aspect_ratio(self, analysis: dict,
                                 thresholds: dict) -> RuleResult:
        ratio = analysis['aspect_ratio']
        threshold = thresholds['aspect_ratio']
        passed = ratio <= threshold

        if ratio <= 3.0:
            score = 100.0
        elif ratio <= threshold:
            score = 100.0 * (1.0 - (ratio - 3.0) / (threshold - 3.0) * 0.4)
        else:
            score = max(0, 60.0 * (1.0 - (ratio - threshold) / threshold))

        return RuleResult(
            rule_name='aspect_ratio',
            description=self.rules['aspect_ratio']['name'],
            passed=passed,
            value=round(ratio, 2),
            threshold=threshold,
            unit='ratio',
            score=round(score, 1),
            details=f"종횡비(H/W): {ratio:.2f} / 기준: {threshold} "
                    f"| 높이: {analysis['height']:.1f}, 너비: {analysis['width']:.1f}",
        )

    def _evaluate_min_feature(self, analysis: dict,
                                thresholds: dict) -> RuleResult:
        min_edge = analysis['min_edge_length']
        threshold = thresholds['min_feature_size']
        passed = min_edge >= threshold

        if min_edge >= threshold * 3:
            score = 100.0
        elif min_edge >= threshold:
            score = 50.0 + 50.0 * (min_edge - threshold) / (threshold * 2)
        else:
            score = max(0, 50.0 * min_edge / threshold)

        return RuleResult(
            rule_name='min_feature_size',
            description=self.rules['min_feature_size']['name'],
            passed=passed,
            value=round(min_edge, 3),
            threshold=threshold,
            unit='mm',
            score=round(score, 1),
            details=f"최소 모서리 길이: {min_edge:.3f}mm / 기준: {threshold}mm "
                    f"| 모서리 수: {analysis['edge_count']}",
        )

    def _evaluate_horizontal_hole(self, hole_info: dict,
                                    thresholds: dict) -> RuleResult:
        threshold = thresholds['horizontal_hole_diameter']

        # 단순화: 구멍 분석 결과가 비어있으면 기본 합격
        holes = hole_info.get('estimated_holes', [])

        if not holes:
            return RuleResult(
                rule_name='horizontal_hole_diameter',
                description=self.rules['horizontal_hole_diameter']['name'],
                passed=True,
                value=0.0,
                threshold=threshold,
                unit='mm',
                score=100.0,
                details="탐지된 수평 구멍 없음",
            )

        # 가장 큰 수평 구멍 검사
        max_dia = max(h.get('diameter', 0) for h in holes)
        needs_support = max_dia > threshold
        passed = not needs_support

        if max_dia <= 0:
            score = 100.0
        elif max_dia <= threshold:
            score = 100.0
        else:
            over = (max_dia - threshold) / threshold
            score = max(0, 100.0 * (1.0 - over))

        return RuleResult(
            rule_name='horizontal_hole_diameter',
            description=self.rules['horizontal_hole_diameter']['name'],
            passed=passed,
            value=round(max_dia, 2),
            threshold=threshold,
            unit='mm',
            score=round(score, 1),
            details=f"최대 수평 구멍 직경: {max_dia:.1f}mm / 기준: {threshold}mm",
        )

    # ── 종합 점수 및 등급 ──

    def _compute_total_score(self, rule_results: List[RuleResult]) -> float:
        """가중 평균으로 종합 점수 산출."""
        total = 0.0
        weight_sum = 0.0

        for result in rule_results:
            weight = RULE_WEIGHTS.get(result.rule_name, 0.1)
            total += result.score * weight
            weight_sum += weight

        return round(total / weight_sum if weight_sum > 0 else 0.0, 1)

    @staticmethod
    def _compute_grade(score: float) -> str:
        """점수 → 등급 변환."""
        if score >= 90:
            return 'A'
        elif score >= 80:
            return 'B'
        elif score >= 70:
            return 'C'
        elif score >= 60:
            return 'D'
        else:
            return 'F'

    def _generate_summary(self, rule_results: List[RuleResult],
                            total_score: float, grade: str) -> str:
        """평가 요약 텍스트 생성."""
        passed_count = sum(1 for r in rule_results if r.passed)
        total_count = len(rule_results)

        summary = (f"AM 제조성 평가 결과: {total_score}점 ({grade}등급) | "
                   f"합격 규칙: {passed_count}/{total_count}")
        return summary

    def _generate_suggestions(self, rule_results: List[RuleResult],
                               ptype: ProcessType) -> List[str]:
        """불합격 규칙에 대한 개선 제안 생성."""
        suggestions = []

        for r in rule_results:
            if r.passed:
                continue

            if r.rule_name == 'min_wall_thickness':
                suggestions.append(
                    f"[개선] 최소 벽두께({r.value}mm)가 기준({r.threshold}mm) 미만입니다. "
                    f"벽두께를 {r.threshold}mm 이상으로 증가시키거나, "
                    f"리브(rib) 보강을 추가하세요."
                )
            elif r.rule_name == 'overhang_angle':
                suggestions.append(
                    f"[개선] 오버hang 면적 비율({r.value}%)이 허용치를 초과합니다. "
                    f"빌드 방향을 변경하거나, 45° 이하 오버hang에 챔퍼/필렛을 적용하세요."
                )
            elif r.rule_name == 'support_volume_ratio':
                suggestions.append(
                    f"[개선] 지지구조물 비율({r.value})이 높습니다. "
                    f"설계를 자립형(self-supporting)으로 수정하거나, "
                    f"빌드 방향 최적화를 수행하세요."
                )
            elif r.rule_name == 'build_volume_fit':
                suggestions.append(
                    f"[개선] 부품이 프린터 빌드 볼륨을 초과합니다. "
                    f"부품을 분할하거나 더 큰 프린터를 사용하세요."
                )
            elif r.rule_name == 'aspect_ratio':
                suggestions.append(
                    f"[개선] 종횡비({r.value})가 기준을 초과합니다. "
                    f"빌드 방향을 변경하거나 베이스 플레이트를 넓히세요."
                )
            elif r.rule_name == 'min_feature_size':
                suggestions.append(
                    f"[개선] 최소 특징 크기({r.value}mm)가 기준({r.threshold}mm) 미만입니다. "
                    f"미세 특징을 제거하거나 크기를 증가시키세요."
                )
            elif r.rule_name == 'horizontal_hole_diameter':
                suggestions.append(
                    f"[개선] 수평 구멍 직경({r.value}mm)이 기준({r.threshold}mm)을 초과합니다. "
                    f"구멍을 다이아몬드/눈물방울 형상으로 변경하세요."
                )

        if not suggestions:
            suggestions.append("모든 규칙을 충족합니다. 제조성이 양호합니다.")

        return suggestions


if __name__ == "__main__":
    # 테스트 실행
    engine = AMRuleBase()

    meshes = {
        'box': trimesh.creation.box(extents=[40, 30, 20]),
        'tall_pillar': trimesh.creation.cylinder(radius=2, height=80),
        'thin_wall': trimesh.creation.box(extents=[60, 40, 1]),
    }

    for name, mesh in meshes.items():
        result = engine.evaluate(mesh, process_type='FDM')
        print(f"\n{'='*50}")
        print(f"모델: {name}")
        print(f"종합 점수: {result.total_score} / 등급: {result.grade}")
        for r in result.rule_results:
            status = "✓" if r.passed else "✗"
            print(f"  {status} {r.description}: {r.value} {r.unit} "
                  f"(기준: {r.threshold}) → {r.score}점")
        if result.improvement_suggestions:
            print("  개선 제안:")
            for s in result.improvement_suggestions:
                print(f"    - {s}")