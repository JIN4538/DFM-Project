"""3D 모델 로더 — STL 파일 로드 및 샘플 모델 생성

기능:
- STL 파일 로드 (ASCII/Binary)
- 기본 형상 정보 추출 (바운딩 박스, 부피, 표면적, 무게중심)
- 데모용 샘플 모델 3종 생성 (Good / Bad / Moderate)
"""

import trimesh
import numpy as np
import os


def load_model(filepath: str) -> dict:
    """STL 파일을 로드하여 메시와 메타데이터를 반환합니다.

    Parameters
    ----------
    filepath : str
        STL 파일 경로

    Returns
    -------
    dict
        mesh: trimesh.Trimesh 객체
        metadata: 바운딩박스, 부피, 표면적, 무게중심 등
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"파일을 찾을 수 없습니다: {filepath}")

    mesh = trimesh.load(filepath, force='mesh')

    # 메시 정규화 (법선 벡터 일관성 확보)
    mesh.fix_normals()

    metadata = extract_metadata(mesh)
    metadata['filepath'] = filepath
    metadata['filename'] = os.path.basename(filepath)

    return {'mesh': mesh, 'metadata': metadata}


def extract_metadata(mesh: trimesh.Trimesh) -> dict:
    """메시에서 기본 형상 메타데이터를 추출합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh

    Returns
    -------
    dict
        bounding_box, volume, surface_area, center_mass 등
    """
    bounds = mesh.bounding_box.bounds  # [[xmin,ymin,zmin],[xmax,ymax,zmax]]

    return {
        'bounding_box': {
            'min': bounds[0].tolist(),
            'max': bounds[1].tolist(),
            'size': mesh.bounding_box.extents.tolist(),  # [x, y, z]
        },
        'volume': float(mesh.volume),
        'surface_area': float(mesh.area),
        'center_mass': mesh.center_mass.tolist(),
        'vertex_count': len(mesh.vertices),
        'face_count': len(mesh.faces),
        'is_watertight': mesh.is_watertight,
    }


def generate_sample_models() -> dict:
    """데모용 샘플 3D 모델 3종을 생성합니다.

    Returns
    -------
    dict
        'good': 제조성이 양호한 단순 박스
        'bad': 얇은 벽 + 오버행이 많은 불량 설계
        'moderate': 중간 수준의 브래킷 형상
    """
    models = {}

    # ── Good: 단순 직육면체 (제조성 우수) ──
    good_box = trimesh.creation.box(extents=[40, 30, 20])
    # 필렛 추가로 오버행 감소
    good_box = _add_simple_fillet(good_box)
    models['good'] = {
        'mesh': good_box,
        'name': 'Good Design (간단한 박스)',
        'description': '두꺼운 벽, 오버행 없음, 프린터 볼륨 내 존재'
    }

    # ── Bad: 얇은 벽 + 큰 오버hang + 높은 종횡비 ──
    # 얇은 벽 (1mm 두께)
    thin_wall = trimesh.creation.box(extents=[60, 40, 1])
    # 큰 오버hang 플랫폼
    overhang = trimesh.creation.box(extents=[80, 60, 2])
    overhang.apply_translation([0, 0, 1])
    # 높은 기둥 (종횡비 과대)
    tall_pillar = trimesh.creation.cylinder(radius=2, height=80)
    tall_pillar.apply_translation([30, 20, 3])

    bad_mesh = trimesh.util.concatenate([thin_wall, overhang, tall_pillar])
    models['bad'] = {
        'mesh': bad_mesh,
        'name': 'Bad Design (얇은 벽 + 오버행)',
        'description': '1mm 벽두께, 수평 오버행, 높은 기둥 — 제조성 불량'
    }

    # ── Moderate: L형 브래킷 ──
    # 수직 벽
    vert_wall = trimesh.creation.box(extents=[60, 5, 40])
    # 수평 벽 (약간의 오버행 존재)
    horiz_wall = trimesh.creation.box(extents=[60, 40, 5])
    horiz_wall.apply_translation([0, 17.5, -17.5])

    # 보스 (수평 구멍 시뮬레이션용 원통)
    boss = trimesh.creation.cylinder(radius=10, height=10)
    boss.apply_translation([0, 5, 0])

    bracket = trimesh.util.concatenate([vert_wall, horiz_wall])
    models['moderate'] = {
        'mesh': bracket,
        'name': 'Moderate Design (L-브래킷)',
        'description': '적절한 벽두께, 약간의 오버행 존재 — 개선 여지 있음'
    }

    return models


def _add_simple_fillet(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """간단한 필렛 추가 (모서리 둥글게).

    실제 필렛은 복잡하므로, 여기서는 모서리 부근 정점을 약간 이동시켜
    근사 처리합니다.
    """
    # 실제 구현에서는 OpenCASCADE 등 필요
    # 데모에서는 원본 그대로 반환
    return mesh


def save_sample_stl(output_dir: str = "data") -> list:
    """샘플 모델을 STL 파일로 저장합니다.

    Parameters
    ----------
    output_dir : str
        출력 폴더 경로

    Returns
    -------
    list
        저장된 파일 경로 목록
    """
    os.makedirs(output_dir, exist_ok=True)
    models = generate_sample_models()
    paths = []

    for key, model_data in models.items():
        path = os.path.join(output_dir, f"sample_{key}.stl")
        model_data['mesh'].export(path)
        paths.append(path)

    return paths


if __name__ == "__main__":
    # 샘플 STL 파일 생성 테스트
    paths = save_sample_stl()
    for p in paths:
        data = load_model(p)
        meta = data['metadata']
        print(f"{os.path.basename(p)}: "
              f"부피={meta['volume']:.1f}, "
              f"표면적={meta['surface_area']:.1f}, "
              f"크기={meta['bounding_box']['size']}")