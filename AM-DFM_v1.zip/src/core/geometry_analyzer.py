"""형상 분석기 — AM 제조성 평가를 위한 3D 형상 분석

분석 항목:
- 벽두께 분석 (ray casting 기반)
- 오버행 각도 분석 (적층 방향 기준)
- 지지구조물 부피 추정
- 종횡비 계산
- 빌드 볼륨 적합성
- 표면 거칠도 지표
- 구멍 분석
"""

import trimesh
import numpy as np
from typing import Tuple, Dict, List


def compute_wall_thickness(mesh: trimesh.Trimesh,
                           n_samples: int = 500) -> dict:
    """레이 캐스팅 기반 벽두께 분석.

    각 정점에서 법선 방향의 반대쪽으로 레이를 쏴서
    벽두께를 근사 추정합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    n_samples : int
        샘플링할 정점 수 (전체 정점이 너무 많은 경우)

    Returns
    -------
    dict
        min_thickness, mean_thickness, max_thickness,
        thin_points: 두께가 얇은 정점 인덱스 및 좌표
    """
    vertices = mesh.vertices
    normals = mesh.vertex_normals

    # 샘플링 (정점이 너무 많으면 속도 저하)
    if len(vertices) > n_samples:
        indices = np.random.choice(len(vertices), n_samples, replace=False)
    else:
        indices = np.arange(len(vertices))

    thicknesses = []
    thin_indices = []

    for idx in indices:
        origin = vertices[idx]
        direction = -normals[idx]  # 법선 반대 방향

        # 레이 캐스팅: 이 정점에서 반대쪽 벽까지의 거리
        locations, index_ray, index_tri = mesh.ray.intersects_location(
            ray_origins=[origin + direction * 0.01],  # 자가 충돌 방지 offset
            ray_directions=[direction]
        )

        if len(locations) > 0:
            # 가장 가까운 교점까지의 거리
            distances = np.linalg.norm(locations - origin, axis=1)
            min_dist = np.min(distances)
            thicknesses.append(min_dist)
            if min_dist < 1.0:  # 1mm 미만은 얇은 벽
                thin_indices.append(int(idx))
        else:
            thicknesses.append(np.nan)

    thicknesses = np.array(thicknesses)
    valid = thicknesses[~np.isnan(thicknesses)]

    if len(valid) == 0:
        return {
            'min_thickness': 0.0,
            'mean_thickness': 0.0,
            'max_thickness': 0.0,
            'thin_point_indices': [],
            'thin_point_coords': np.empty((0, 3)).tolist(),
            'samples_checked': len(indices),
        }

    return {
        'min_thickness': float(np.min(valid)),
        'mean_thickness': float(np.mean(valid)),
        'max_thickness': float(np.max(valid)),
        'thin_point_indices': thin_indices,
        'thin_point_coords': vertices[thin_indices].tolist() if thin_indices else [],
        'samples_checked': len(indices),
    }


def compute_overhang_angles(mesh: trimesh.Trimesh,
                              build_direction: np.ndarray = None
                              ) -> dict:
    """오버행 각도 분석.

    각 면의 법선 벡터와 적층 방향(빌드 방향) 사이의 각도를 계산하여,
    지지구조가 필요한 면(45° 미만)을 식별합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    build_direction : np.ndarray
        적층 방향 벡터 (기본값: [0, 0, 1] = Z축)

    Returns
    -------
    dict
        overhang_face_indices: 지지구조가 필요한 면의 인덱스
        overhang_angles: 모든 면의 각도 (도)
        critical_angle: 임계각 (도)
        support_ratio: 전체 면적 중 지지구조가 필요한 비율
    """
    if build_direction is None:
        build_direction = np.array([0.0, 0.0, 1.0])
    else:
        build_direction = np.array(build_direction, dtype=float)
        build_direction /= np.linalg.norm(build_direction)

    # 면 법선 추출
    face_normals = mesh.face_normals  # (F, 3)

    # 각 면 법선과 빌드 방향 사이의 각도
    # cos(angle) = dot(normal, build_dir)
    dots = np.dot(face_normals, build_direction)
    dots = np.clip(dots, -1.0, 1.0)
    angles_rad = np.arccos(dots)
    angles_deg = np.degrees(angles_rad)

    # 오버hang 각도 = 수평면으로부터의 각도
    # 90° - 법선각도 = 오버행 각도
    overhang_angles_deg = 90.0 - angles_deg

    # 음수 처리 (아래를 향하는 면은 오버행이 아님)
    overhang_angles_deg = np.clip(overhang_angles_deg, 0, 90)

    # 임계각: 45° 미만 면은 지지구조 필요
    CRITICAL_ANGLE = 45.0  # ISO/ASTM 52910 기준
    support_needed = overhang_angles_deg < CRITICAL_ANGLE

    # 지지구조가 필요한 면 중 실제로 아래를 향하는 면만 필터링
    # (법선이 빌드 방향과 반대 방향이 아니면 제외)
    # 빌드 방향과 법선이 이루는 각이 < 90°면 아래를 향함
    # 실제로는 overhang_angles < 45 AND face가 "아래를 향함"
    # 단순화: normal·build_dir > 0 인 것만 위를 향함
    # 지지구조 필요 조건: overhang_angle < 45 AND 면이 바닥 방향
    is_facing_down = dots > 0  # 법선이 빌드 방향과 같은 방향 → 위를 향함
    is_facing_down = ~is_facing_down  # 아래를 향함

    # 실제 오버행: 아래를 향하면서 각도가 완만한 면
    overhang_faces = support_needed & is_facing_down

    # 면적 비율 계산
    face_areas = mesh.area_faces
    total_area = mesh.area
    overhang_area = np.sum(face_areas[overhang_faces])
    support_ratio = overhang_area / total_area if total_area > 0 else 0.0

    return {
        'overhang_face_indices': np.where(overhang_faces)[0].tolist(),
        'overhang_angles': overhang_angles_deg.tolist(),
        'critical_angle': CRITICAL_ANGLE,
        'support_ratio': float(support_ratio),
        'overhang_area': float(overhang_area),
        'total_face_count': len(mesh.faces),
        'overhang_face_count': int(np.sum(overhang_faces)),
    }


def compute_support_volume(mesh: trimesh.Trimesh,
                             build_direction: np.ndarray = None
                             ) -> dict:
    """지지구조물 부피 추정.

    오버hang 면 아래의 부피를 근사적으로 추정합니다.
    각 오버hang 면에 대해 빌드 방향으로 투영한 높이만큼의
    지지구조물 부피를 계산합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    build_direction : np.ndarray

    Returns
    -------
    dict
        support_volume, part_volume, support_ratio
    """
    if build_direction is None:
        build_direction = np.array([0.0, 0.0, 1.0])

    overhang_result = compute_overhang_angles(mesh, build_direction)
    overhang_indices = overhang_result['overhang_face_indices']

    if len(overhang_indices) == 0:
        return {
            'support_volume': 0.0,
            'part_volume': float(mesh.volume),
            'support_ratio': 0.0,
        }

    # 각 오버hang 면의 중심에서 빌드 방향의 반대로 레이를 쏴서
    # 바닥까지의 거리 → 지지구조물 높이
    face_centers = mesh.triangles_center[overhang_indices]

    # 바닥 높이 (빌드 방향 기준 최저점)
    projections = np.dot(mesh.vertices, build_direction)
    base_height = float(np.min(projections))

    # 각 오버hang 면 중심의 높이
    face_heights = np.dot(face_centers, build_direction)

    # 지지구조물 높이 = 면 높이 - 바닥 높이
    support_heights = face_heights - base_height
    support_heights = np.maximum(support_heights, 0)

    # 지지구조물 부피 = Σ(면적 × 높이 × 지지체 비율)
    # 실제 지지구조물은 100% 채우는 것이 아니므로 40% 밀도 가정
    SUPPORT_DENSITY = 0.4
    face_areas = mesh.area_faces[overhang_indices]
    support_volume = float(np.sum(face_areas * support_heights) * SUPPORT_DENSITY)

    part_volume = float(mesh.volume)
    support_ratio = support_volume / part_volume if part_volume > 0 else 0.0

    return {
        'support_volume': support_volume,
        'part_volume': part_volume,
        'support_ratio': support_ratio,
    }


def compute_aspect_ratio(mesh: trimesh.Trimesh) -> dict:
    """종횡비 계산.

    빌드 방향(Z축) 기준 높이/너비 비율.

    Returns
    -------
    dict
        aspect_ratio, height, width
    """
    extents = mesh.bounding_box.extents  # [x, y, z]
    height = float(extents[2])  # Z축 = 빌드 방향 가정
    width = float(max(extents[0], extents[1]))

    aspect_ratio = height / width if width > 0 else 0.0

    return {
        'aspect_ratio': aspect_ratio,
        'height': height,
        'width': width,
    }


def compute_build_volume_fit(mesh: trimesh.Trimesh,
                               printer_dims: list = None) -> dict:
    """빌드 볼륨 적합성 검사.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    printer_dims : list
        프린터 빌드 볼륨 [X, Y, Z] mm (기본: 250×250×250)

    Returns
    -------
    dict
        fits: bool, part_size, printer_size, margin
    """
    if printer_dims is None:
        printer_dims = [250.0, 250.0, 250.0]

    part_size = mesh.bounding_box.extents.tolist()
    fits = all(p <= d for p, d in zip(part_size, printer_dims))
    margin = [d - p for d, p in zip(printer_dims, part_size)]

    return {
        'fits': fits,
        'part_size': part_size,
        'printer_size': printer_dims,
        'margin': margin,
    }


def compute_min_feature_size(mesh: trimesh.Trimesh) -> dict:
    """최소 특징 크기 추정.

    메시에서 가장 작은 특징(가장 짧은 모서리)을 찾습니다.

    Returns
    -------
    dict
        min_edge_length, min_face_area, edge_count
    """
    edges = mesh.edges_unique
    vertices = mesh.vertices

    # 모서리 길이 계산
    edge_vecs = vertices[edges[:, 1]] - vertices[edges[:, 0]]
    edge_lengths = np.linalg.norm(edge_vecs, axis=1)

    # 면적
    face_areas = mesh.area_faces

    return {
        'min_edge_length': float(np.min(edge_lengths)) if len(edge_lengths) > 0 else 0.0,
        'mean_edge_length': float(np.mean(edge_lengths)) if len(edge_lengths) > 0 else 0.0,
        'min_face_area': float(np.min(face_areas)) if len(face_areas) > 0 else 0.0,
        'edge_count': len(edge_lengths),
    }


def compute_hole_analysis(mesh: trimesh.Trimesh,
                            build_direction: np.ndarray = None) -> dict:
    """구멍 분석 (수평 방향 구멍 크기).

    단순화된 접근: 메시의 단면을 분석하여
    수평 방향(빌드 방향에 수직)의 통과 구멍을 추정합니다.

    Returns
    -------
    dict
        estimated_holes: list of {diameter, axis, needs_support}
    """
    if build_direction is None:
        build_direction = np.array([0.0, 0.0, 1.0])

    # 단순화: 바운딩 박스 기반 추정
    # 실제 구현에서는 형상 특징 인식(feature recognition) 필요
    extents = mesh.bounding_box.extents

    # 이웃한 차원 간 크기 차이로 구멍 유추 (매우 근사적)
    # 실제 프로덕션에서는 pythonOCC 기반 특징 인식 필요
    holes = []

    # 데모 목적: X방향 통과 구멍 추정
    x_pass = extents[0]
    y_pass = extents[1]
    z_pass = extents[2]

    # Z방향(빌드 방향)에 수평인 구멍 = X 또는 Y 방향 통과
    HORIZONTAL_HOLE_LIMIT = 8.0  # mm (FDM 기준)

    return {
        'estimated_holes': holes,
        'note': '정밀한 구멍 분석은 pythonOCC 기반 특징 인식이 필요합니다.',
        'horizontal_hole_support_threshold': HORIZONTAL_HOLE_LIMIT,
    }


def run_full_analysis(mesh: trimesh.Trimesh,
                       build_direction: np.ndarray = None,
                       printer_dims: list = None) -> dict:
    """전체 형상 분석을 한 번에 실행합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    build_direction : np.ndarray, optional
    printer_dims : list, optional

    Returns
    -------
    dict
        모든 분석 결과가 통합된 딕셔너리
    """
    if build_direction is None:
        build_direction = np.array([0.0, 0.0, 1.0])
    if printer_dims is None:
        printer_dims = [250.0, 250.0, 250.0]

    return {
        'wall_thickness': compute_wall_thickness(mesh),
        'overhang': compute_overhang_angles(mesh, build_direction),
        'support_volume': compute_support_volume(mesh, build_direction),
        'aspect_ratio': compute_aspect_ratio(mesh),
        'build_volume_fit': compute_build_volume_fit(mesh, printer_dims),
        'min_feature_size': compute_min_feature_size(mesh),
        'hole_analysis': compute_hole_analysis(mesh, build_direction),
    }


if __name__ == "__main__":
    # 테스트
    mesh = trimesh.creation.box(extents=[40, 30, 20])
    results = run_full_analysis(mesh)
    for key, val in results.items():
        print(f"\n[{key}]")
        for k, v in val.items():
            if isinstance(v, list) and len(v) > 5:
                print(f"  {k}: [{len(v)} items]")
            else:
                print(f"  {k}: {v}")