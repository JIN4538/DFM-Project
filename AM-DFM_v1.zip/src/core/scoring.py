"""평가 결과 관리 및 빌드 방향 비교

기능:
- 평가 결과 정렬 및 요약
- 빌드 방향별 비교 분석
- 개선 제안 생성
- 결과 내보내기
"""

import numpy as np
import trimesh
from typing import Dict, List, Optional
from dataclasses import asdict

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.processes.additive import AMRuleBase, EvaluationResult, ProcessType


def evaluate_all_orientations(mesh: trimesh.Trimesh,
                                process_type: str = 'FDM',
                                printer_dims: list = None) -> Dict[str, EvaluationResult]:
    """3가지 빌드 방향(X, Y, Z)에 대해 순차 평가합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    process_type : str
    printer_dims : list

    Returns
    -------
    dict
        key: 'X축', 'Y축', 'Z축'
        value: EvaluationResult
    """
    engine = AMRuleBase()

    orientations = {
        'Z축 (기본)': [0, 0, 1],
        'X축': [1, 0, 0],
        'Y축': [0, 1, 0],
    }

    results = {}
    for label, direction in orientations.items():
        result = engine.evaluate(
            mesh,
            process_type=process_type,
            build_direction=direction,
            printer_dims=printer_dims,
        )
        results[label] = result

    return results


def find_optimal_orientation(mesh: trimesh.Trimesh,
                               process_type: str = 'FDM',
                               printer_dims: list = None) -> dict:
    """최적 빌드 방향을 탐색합니다.

    Returns
    -------
    dict
        best_orientation, best_score, all_results
    """
    results = evaluate_all_orientations(mesh, process_type, printer_dims)

    best_label = None
    best_score = -1
    for label, result in results.items():
        if result.total_score > best_score:
            best_score = result.total_score
            best_label = label

    return {
        'best_orientation': best_label,
        'best_score': best_score,
        'all_results': results,
    }


def results_to_dict(result: EvaluationResult) -> dict:
    """EvaluationResult를 일반 dict로 변환 (JSON 저장 가능)."""
    d = asdict(result)
    return d


def results_to_table(results: Dict[str, EvaluationResult]) -> list:
    """여러 방향의 평가 결과를 비교 표 형태로 변환합니다.

    Returns
    -------
    list of dict
        각 행: {규칙명, Z축_점수, X축_점수, Y축_점수, ...}
    """
    # 규칙명 목록
    rule_names = [r.rule_name for r in list(results.values())[0].rule_results]

    rows = []
    for rule_name in rule_names:
        row = {'규칙': rule_name}
        for orient_label, result in results.items():
            for r in result.rule_results:
                if r.rule_name == rule_name:
                    row[f'{orient_label}_점수'] = r.score
                    row[f'{orient_label}_값'] = r.value
                    row[f'{orient_label}_합격'] = r.passed
                    break
        rows.append(row)

    # 종합 행 추가
    total_row = {'규칙': '종합 점수'}
    for orient_label, result in results.items():
        total_row[f'{orient_label}_점수'] = result.total_score
        total_row[f'{orient_label}_값'] = '-'
        total_row[f'{orient_label}_합격'] = result.grade in ['A', 'B']
    rows.append(total_row)

    return rows


if __name__ == "__main__":
    # 테스트: L-브래킷 모델
    mesh = trimesh.util.concatenate([
        trimesh.creation.box(extents=[60, 5, 40]),
        trimesh.creation.box(extents=[60, 40, 5]),
    ])

    # 최적 방향 탐색
    opt = find_optimal_orientation(mesh)
    print(f"최적 빌드 방향: {opt['best_orientation']} "
          f"(점수: {opt['best_score']})")

    # 비교 표
    table = results_to_table(opt['all_results'])
    print("\n방향별 비교:")
    for row in table:
        scores = {k: v for k, v in row.items() if '점수' in k}
        print(f"  {row['규칙']}: {scores}")