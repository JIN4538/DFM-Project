"""AM-DFM Evaluator — Streamlit 웹 애플리케이션

적층제조 제조성 검토 소프트웨어의 사용자 인터페이스입니다.
3D 모델을 로드하고, ISO/ASTM 52910 기반 규칙으로 제조성을 평가합니다.

Usage:
    streamlit run run_app.py
"""

import streamlit as st
import trimesh
import numpy as np
import plotly.graph_objects as go
import tempfile
import os
import sys

# 경로 설정
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from src.core.model_loader import load_model, generate_sample_models, save_sample_stl
from src.core.geometry_analyzer import (
    compute_overhang_angles,
    run_full_analysis,
)
from src.processes.additive import AMRuleBase, EvaluationResult
from src.core.scoring import (
    evaluate_all_orientations,
    find_optimal_orientation,
    results_to_table,
)


# ── 페이지 설정 ──
st.set_page_config(
    page_title="AM-DFM Evaluator",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── 세션 상태 초기화 ──
if 'mesh' not in st.session_state:
    st.session_state.mesh = None
if 'evaluation_result' not in st.session_state:
    st.session_state.evaluation_result = None
if 'sample_stl_paths' not in st.session_state:
    st.session_state.sample_stl_paths = None


def render_3d_model(mesh: trimesh.Trimesh,
                     overhang_faces: list = None) -> go.Figure:
    """3D 모델을 Plotly로 렌더링합니다.

    Parameters
    ----------
    mesh : trimesh.Trimesh
    overhang_faces : list, optional
        오버hang 면 인덱스 (빨간색으로 하이라이트)

    Returns
    -------
    plotly.graph_objects.Figure
    """
    vertices = mesh.vertices
    faces = mesh.faces

    # 메시 좌표
    x = vertices[:, 0]
    y = vertices[:, 1]
    z = vertices[:, 2]
    i_idx = faces[:, 0]
    j_idx = faces[:, 1]
    k_idx = faces[:, 2]

    # 기본 면 색상 (파란색 계열)
    face_colors = np.full((len(faces), 4), [0.3, 0.5, 0.8, 0.8])

    # 오버hang 면 빨간색으로 하이라이트
    if overhang_faces and len(overhang_faces) > 0:
        for idx in overhang_faces:
            if idx < len(face_colors):
                face_colors[idx] = [0.9, 0.2, 0.2, 0.9]

    fig = go.Figure(data=[
        go.Mesh3d(
            x=x, y=y, z=z,
            i=i_idx, j=j_idx, k=k_idx,
            facecolor=face_colors,
            flatshading=True,
            lighting=dict(ambient=0.5, diffuse=0.8, specular=0.2),
            lightposition=dict(x=100, y=200, z=300),
        )
    ])

    fig.update_layout(
        scene=dict(
            xaxis_title='X (mm)',
            yaxis_title='Y (mm)',
            zaxis_title='Z (mm)',
            aspectmode='data',
        ),
        margin=dict(l=0, r=0, t=30, b=0),
        height=500,
        title="3D 모델 (빨간색 = 오버hang 면)",
    )

    return fig


def render_score_gauge(score: float, grade: str) -> go.Figure:
    """점수 게이지 차트를 그립니다.

    Parameters
    ----------
    score : float (0~100)
    grade : str (A~F)

    Returns
    -------
    plotly.graph_objects.Figure
    """
    grade_colors = {'A': '#27ae60', 'B': '#2ecc71', 'C': '#f39c12',
                    'D': '#e67e22', 'F': '#e74c3c'}
    color = grade_colors.get(grade, '#95a5a6')

    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=score,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': f"등급: {grade}", 'font': {'size': 24}},
        delta={'reference': 80},
        gauge={
            'axis': {'range': [None, 100], 'tickwidth': 1},
            'bar': {'color': color, 'thickness': 0.6},
            'steps': [
                {'range': [0, 60], 'color': '#fde8e8'},
                {'range': [60, 80], 'color': '#fef3cd'},
                {'range': [80, 100], 'color': '#d4edda'},
            ],
            'threshold': {
                'line': {'color': "black", 'width': 3},
                'thickness': 0.8,
                'value': 80,
            }
        },
        number={'font': {'size': 40}},
    ))

    fig.update_layout(height=300, margin=dict(l=30, r=30, t=60, b=0))

    return fig


def render_radar_chart(rule_results) -> go.Figure:
    """규칙별 점수를 레이더 차트로 시각화합니다."""
    categories = []
    scores = []

    short_names = {
        'min_wall_thickness': 'Min Wall',
        'overhang_angle': 'Overhang',
        'support_volume_ratio': 'Support Vol',
        'build_volume_fit': 'Build Vol',
        'aspect_ratio': 'Aspect Ratio',
        'min_feature_size': 'Min Feature',
        'horizontal_hole_diameter': 'Horiz. Hole',
    }

    for r in rule_results:
        name = short_names.get(r.rule_name, r.rule_name)
        categories.append(name)
        scores.append(r.score)

    fig = go.Figure(data=go.Scatterpolar(
        r=scores + [scores[0]],
        theta=categories + [categories[0]],
        fill='toself',
        name='Score',
        line=dict(color='#2980b9', width=2),
        fillcolor='rgba(41, 128, 185, 0.2)',
    ))

    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 100]),
        ),
        showlegend=False,
        height=400,
        title="규칙별 점수 레이더 차트",
    )

    return fig


def main():
    """Streamlit 앱 메인 함수."""

    # ── 사이드바 ──
    with st.sidebar:
        st.title("🔧 AM-DFM Evaluator")
        st.markdown("---")
        st.subheader("모델 입력")

        # 모델 선택
        input_method = st.radio(
            "모델 입력 방식",
            ["샘플 모델 사용", "STL 파일 업로드"],
            index=0,
        )

        mesh = None
        model_name = ""

        if input_method == "샘플 모델 사용":
            sample_choice = st.selectbox(
                "샘플 모델 선택",
                ["Good (간단한 박스)", "Bad (얇은 벽 + 오버행)", "Moderate (L-브래킷)"],
            )

            # 샘플 STL 생성 (최초 1회)
            if st.session_state.sample_stl_paths is None:
                with st.spinner("샘플 모델 생성 중..."):
                    st.session_state.sample_stl_paths = save_sample_stl("data")

            sample_map = {
                "Good (간단한 박스)": ("good", 0),
                "Bad (얇은 벽 + 오버행)": ("bad", 1),
                "Moderate (L-브래킷)": ("moderate", 2),
            }
            key, idx = sample_map[sample_choice]

            # 샘플 모델 직접 생성 (STL 경유 대신)
            models = generate_sample_models()
            mesh = models[key]['mesh']
            model_name = models[key]['name']

        else:
            uploaded = st.file_uploader(
                "STL 파일을 업로드하세요",
                type=['stl'],
            )
            if uploaded is not None:
                # 임시 파일로 저장 후 로드
                with tempfile.NamedTemporaryFile(suffix='.stl', delete=False) as f:
                    f.write(uploaded.getvalue())
                    temp_path = f.name

                try:
                    model_data = load_model(temp_path)
                    mesh = model_data['mesh']
                    model_name = model_data['metadata']['filename']
                except Exception as e:
                    st.error(f"파일 로드 오류: {e}")
                finally:
                    os.unlink(temp_path)

        st.markdown("---")
        st.subheader("공정 설정")

        process_type = st.selectbox(
            "공정 유형 (Process Type)",
            ["FDM", "SLA", "SLS", "DMLS"],
            index=0,
            help="FDM: 용융압출, SLA: 광경화, SLS: 선택적 레이저 소결, DMLS: 직접 금속 소결",
        )

        build_dir_label = st.selectbox(
            "빌드 방향 (Build Direction)",
            ["Z축 (기본)", "X축", "Y축"],
            index=0,
        )

        build_dir_map = {
            "Z축 (기본)": [0, 0, 1],
            "X축": [1, 0, 0],
            "Y축": [0, 1, 0],
        }
        build_direction = build_dir_map[build_dir_label]

        printer_x = st.number_input("프린터 X (mm)", value=250, min_value=50)
        printer_y = st.number_input("프린터 Y (mm)", value=250, min_value=50)
        printer_z = st.number_input("프린터 Z (mm)", value=250, min_value=50)
        printer_dims = [float(printer_x), float(printer_y), float(printer_z)]

        st.markdown("---")

        analyze_btn = st.button(
            "🔍 제조성 평가 실행",
            type="primary",
            use_container_width=True,
            disabled=(mesh is None),
        )

    # ── 메인 영역 ──
    st.title("AM 제조성 검토 (Design for Additive Manufacturing)")
    st.caption("ISO/ASTM 52910 기반 | 적층제조 부품 제조성 자동 평가 시스템")

    if mesh is None:
        st.info("👈 사이드바에서 모델을 선택하거나 STL 파일을 업로드하세요.")
        return

    # 모델 정보 표시
    with st.expander("📐 모델 기본 정보", expanded=True):
        col1, col2, col3, col4 = st.columns(4)
        ext = mesh.bounding_box.extents
        col1.metric("부피 (mm³)", f"{mesh.volume:.1f}")
        col2.metric("표면적 (mm²)", f"{mesh.area:.1f}")
        col3.metric("크기 (mm)", f"{ext[0]:.1f}×{ext[1]:.1f}×{ext[2]:.1f}")
        col4.metric("면/정점 수", f"{len(mesh.faces)}/{len(mesh.vertices)}")

    # 3D 뷰어
    st.subheader("3D 모델 뷰어")
    overhang_faces = []
    if st.session_state.evaluation_result is not None:
        for r in st.session_state.evaluation_result.rule_results:
            if r.rule_name == 'overhang_angle':
                overhang_faces = r.problem_face_indices[:500]

    fig_3d = render_3d_model(mesh, overhang_faces)
    st.plotly_chart(fig_3d, use_container_width=True)

    # 평가 실행
    if analyze_btn or st.session_state.evaluation_result is not None:
        if analyze_btn:
            with st.spinner("제조성 평가 중..."):
                engine = AMRuleBase()
                result = engine.evaluate(
                    mesh,
                    process_type=process_type,
                    build_direction=build_direction,
                    printer_dims=printer_dims,
                )
                st.session_state.evaluation_result = result
                # 오버hang 면 업데이트를 위해 리렌더
                st.rerun()
        else:
            result = st.session_state.evaluation_result

        st.markdown("---")

        # ── 종합 점수 ──
        score_col, gauge_col = st.columns([1, 2])

        with score_col:
            st.subheader("종합 평가")
            grade_colors = {'A': '🟢', 'B': '🟢', 'C': '🟡', 'D': '🟠', 'F': '🔴'}
            emoji = grade_colors.get(result.grade, '⚪')
            st.markdown(f"## {emoji} {result.total_score}점 / {result.grade}등급")
            st.markdown(f"공정: {result.process_type}")
            st.markdown(f"빌드 방향: {build_dir_label}")

            passed = sum(1 for r in result.rule_results if r.passed)
            st.progress(passed / len(result.rule_results),
                        text=f"합격 규칙: {passed}/{len(result.rule_results)}")

        with gauge_col:
            fig_gauge = render_score_gauge(result.total_score, result.grade)
            st.plotly_chart(fig_gauge, use_container_width=True)

        # ── 레이더 차트 ──
        st.subheader("규칙별 점수 분포")
        fig_radar = render_radar_chart(result.rule_results)
        st.plotly_chart(fig_radar, use_container_width=True)

        # ── 규칙별 상세 결과 ──
        st.subheader("규칙별 평가 상세")
        for r in result.rule_results:
            status_icon = "✅" if r.passed else "❌"
            bg_color = "#d4edda" if r.passed else "#f8d7da"

            with st.container():
                col_name, col_val, col_score = st.columns([3, 2, 1])
                with col_name:
                    st.markdown(f"{status_icon} {r.description}")
                    st.caption(r.rule_name)
                with col_val:
                    st.markdown(f"`{r.value}` {r.unit} / 기준: `{r.threshold}`")
                    st.caption(r.details)
                with col_score:
                    st.markdown(f"## {r.score}")
                    st.progress(r.score / 100)

        # ── 개선 제안 ──
        st.subheader("개선 제안 (Improvement Suggestions)")
        for i, s in enumerate(result.improvement_suggestions, 1):
            if "모든 규칙" in s:
                st.success(s)
            else:
                st.warning(f"{i}. {s}")

        # ── 빌드 방향 비교 ──
        st.subheader("빌드 방향별 비교")

        with st.spinner("각 빌드 방향에 대해 평가 중..."):
            all_results = evaluate_all_orientations(
                mesh, process_type, printer_dims
            )

        # 비교 표
        table_data = results_to_table(all_results)
        short_names = {
            'min_wall_thickness': 'Min Wall Thickness',
            'overhang_angle': 'Overhang Angle',
            'support_volume_ratio': 'Support Volume Ratio',
            'build_volume_fit': 'Build Volume Fit',
            'aspect_ratio': 'Aspect Ratio',
            'min_feature_size': 'Min Feature Size',
            'horizontal_hole_diameter': 'Horizontal Hole Dia.',
        }

        display_rows = []
        for row in table_data:
            rule = short_names.get(row['규칙'], row['규칙'])
            display_rows.append({
                '규칙': rule,
                'Z축 점수': row.get('Z축 (기본)_점수', '-'),
                'X축 점수': row.get('X축_점수', '-'),
                'Y축 점수': row.get('Y축_점수', '-'),
            })

        st.dataframe(display_rows, use_container_width=True, hide_index=True)

        # 최적 방향
        opt = find_optimal_orientation(mesh, process_type, printer_dims)
        st.success(f"🏆 최적 빌드 방향: {opt['best_orientation']} "
                   f"(점수: {opt['best_score']})")

    # ── 푸터 ──
    st.markdown("---")
    st.caption("AM-DFM Evaluator v1.0 | ISO/ASTM 52910 기반 | "
               "Ref: Oh, Kwon et al. (2021), Additive Manufacturing, 37, 101702")


if __name__ == "__main__":
    main()