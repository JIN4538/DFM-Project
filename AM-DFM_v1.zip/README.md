# AM 제조성 검토 소프트웨어 (AM-DFM Evaluator)

적층제조(Additive Manufacturing) 부품의 제조성을 ISO/ASTM 52910 기반 규칙으로 평가합니다.

## 실행 방법
```bash
conda activate dfm
cd dfm_project
streamlit run run_app.py
```

## 평가 항목
- 최소 벽두께 (Min Wall Thickness)
- 오버행 각도 (Overhang Angle)
- 지지구조물 부피 비율 (Support Volume Ratio)
- 빌드 볼륨 적합성 (Build Volume Fit)
- 종횡비 (Aspect Ratio)
- 최소 특징 크기 (Min Feature Size)
- 수평 구멍 직경 (Horizontal Hole Diameter)

## 기반 표준
- ISO/ASTM 52910: Additive manufacturing — Design — Required principles
- Oh, Y., Ko, H., Sprock, T., Bernstein, W.Z. and Kwon, S. (2021)