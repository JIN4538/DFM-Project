"""DFM Project - 실행 진입점
Usage: streamlit run run_app.py
"""
import sys
import os

# src 폴더를 Python 경로에 추가
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.ui.app import main

if __name__ == "__main__":
    main()