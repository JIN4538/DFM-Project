"""Cura 대조 외부 검증 도구

지금까지의 검증(verify.py)은 모두 자기 일관성 검사다. '의도한 대로 계산하는가'는
확인했지만 '그 의도가 현실과 맞는가'는 확인하지 못했다. 상용 슬라이서가 실제로
생성하는 지지구조물 부피와 우리 추정치를 대조하면 그 간극을 좁힐 수 있다.

사용법
------
1) 슬라이싱할 STL 과 기록표를 생성한다.

       python cura_check.py export --stl NIST.stl --out cura_run

   cura_run/ 아래에 방향별 STL 과 measurements.csv 가 만들어진다.
   measurements.csv 에는 우리 도구의 예측값이 이미 채워져 있고,
   Cura 에서 읽은 값을 넣을 빈 칸이 있다.

2) Cura 로 각 STL 을 서포트 끄고 한 번, 켜고 한 번 슬라이싱해서
   필라멘트 사용량(m)을 measurements.csv 에 적는다.

3) 분석한다.

       python cura_check.py analyze --csv cura_run/measurements.csv

   상관계수, 계통 편향, 그리고 보정된 서포트 밀도 상수를 출력한다.
"""

import argparse
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import trimesh

from src.core import geometry_analyzer as ga
from src.core.scoring import AXIS_ORIENTATIONS
from src.processes.additive import AMRuleEngine, PROCESS_PARAMS, ProcessType

# 1.75mm 필라멘트 단면적 (mm^2). Cura 가 보고하는 길이를 부피로 바꾼다.
FILAMENT_AREA_175 = np.pi * (1.75 / 2.0) ** 2      # 2.4053
FILAMENT_AREA_285 = np.pi * (2.85 / 2.0) ** 2      # 6.3794

COLUMNS = [
    'file', 'orientation', 'process', 'printer_xyz',
    'pred_support_mm3', 'pred_overhang_pct', 'pred_score', 'pred_grade',
    'cura_len_no_support_m', 'cura_len_with_support_m',
    'cura_time_no_support_min', 'cura_time_with_support_min', 'note',
]


def export(stl_paths, out_dir, process='FDM', printer=(300, 300, 340),
           orientations=None):
    os.makedirs(out_dir, exist_ok=True)
    engine = AMRuleEngine()
    orientations = orientations or AXIS_ORIENTATIONS
    rows = []

    for path in stl_paths:
        name = os.path.splitext(os.path.basename(path))[0]
        mesh = trimesh.load(path, force='mesh')
        mesh.fix_normals()
        print(f"\n[{name}] 면 {len(mesh.faces):,}개 · 부피 {mesh.volume:,.1f}mm³ · "
              f"닫힘={mesh.is_watertight}")

        for label, d in orientations.items():
            # Cura 는 항상 +Z 로 쌓으므로, 평가하려는 방향이 +Z 가 되도록
            # 실제로 회전시킨 STL 을 내보낸다. 그래야 두 도구가 같은 조건이 된다.
            m = ga.to_build_frame(mesh, d)
            m.apply_translation([0, 0, -m.bounds[0][2]])       # 바닥을 z=0 에 맞춤

            # 파일명은 ASCII 로 (윈도우/Cura 경로 문제 방지)
            # 엑셀은 + 나 - 로 시작하는 셀을 수식으로 해석해 #NAME? 오류를 낸다.
            # 따라서 CSV 에는 부호 대신 pos/neg 표기를 쓴다.
            safe = {'+Z (기본)': 'posZ', '-Z (뒤집기)': 'negZ', '+X': 'posX',
                    '-X': 'negX', '+Y': 'posY', '-Y': 'negY'}.get(
                        label, ''.join(c for c in label if c.isalnum()))
            fn = f"{name}__{safe}.stl"
            m.export(os.path.join(out_dir, fn))

            r = engine.evaluate(mesh, process, d, printer)

            # 서포트 부피는 벽두께·빌드볼륨 게이트와 독립적인 양이므로,
            # 게이트에 걸린 부품도 대조 자료로는 유효하다.
            # 이전 구현은 인쇄 불가 부품의 예측값을 비워 두어, 게이트에 걸린
            # 모델(예: 얇은 특징이 있는 시험 아티팩트)의 Cura 대조 자료가
            # 통째로 버려졌다.
            P = PROCESS_PARAMS[ProcessType[process]]
            sv = ga.compute_support_volume(ga.to_build_frame(mesh, d),
                                           P['critical_angle'], P['support_density'],
                                           P['support_wall'])
            oh = next((x for x in r.rule_results
                       if x.rule_name == 'overhang_area'), None)
            gate_note = '' if r.feasible else (
                '하드 게이트 위반: ' + ', '.join(g.name for g in r.gates if not g.passed))

            rows.append({
                'file': fn, 'orientation': safe, 'process': process,
                'printer_xyz': 'x'.join(str(int(v)) for v in printer),
                'pred_support_mm3': round(sv['support_volume'], 1),
                'pred_overhang_pct': (oh.value if oh and oh.value is not None else ''),
                'pred_score': (r.total_score if r.total_score is not None else ''),
                'pred_grade': r.grade,
                'cura_len_no_support_m': '', 'cura_len_with_support_m': '',
                'cura_time_no_support_min': '', 'cura_time_with_support_min': '',
                'note': gate_note,
            })
            mark = '' if r.feasible else f'  [인쇄 불가 — {gate_note}]'
            print(f"   {label:12s} -> {fn:44s} 예측 서포트 "
                  f"{sv['support_volume']:9.1f}mm³  등급 {r.grade}{mark}")

    csv_path = os.path.join(out_dir, 'measurements.csv')
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS)
        w.writeheader()
        w.writerows(rows)

    print(f"\nSTL {len(rows)}개와 기록표를 만들었다: {csv_path}")
    print("Cura 설정을 아래로 맞춘 뒤 각 STL 을 서포트 OFF / ON 두 번 슬라이싱한다.")
    print("  · Support Overhang Angle       = 45")
    print("  · Support Density              = 15%")
    print("  · Support Placement            = Everywhere")
    print("  · Build Plate Adhesion         = None  (브림/스커트가 총량에 섞이지 않게)")
    print("  · 모델을 회전시키지 말 것 (STL 에 이미 방향이 반영되어 있다)")
    return csv_path


def analyze(csv_path, filament_dia=1.75, verbose=True):
    area = FILAMENT_AREA_285 if abs(filament_dia - 2.85) < 0.1 else FILAMENT_AREA_175
    rows = []
    with open(csv_path, encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            try:
                off = float(r['cura_len_no_support_m'])
                on = float(r['cura_len_with_support_m'])
                pred = float(r['pred_support_mm3'])
            except (ValueError, TypeError, KeyError):
                continue
            meas = (on - off) * 1000.0 * area          # m -> mm -> mm^3
            rows.append({'file': r['file'], 'orientation': r['orientation'],
                         'pred': pred, 'meas': meas})

    if len(rows) < 3:
        print(f"분석 가능한 행이 {len(rows)}개뿐이다. 최소 3개, 권장 10개 이상 채운다.")
        return None

    # STL 이 CSV 옆에 있으면 물리 항을 다시 계산해 다항 모델까지 비교한다.
    base_dir = os.path.dirname(os.path.abspath(csv_path))
    _P = PROCESS_PARAMS[ProcessType.FDM]
    crit, brl = _P['critical_angle'], _P['bridge_limit']
    term_fail = {}
    if not hasattr(ga, 'support_terms'):
        term_fail['모듈 구버전'] = ("src/core/geometry_analyzer.py 에 support_terms 가 없다. "
                                "cura_check.py 만 바꾸면 안 되고 src 폴더도 함께 교체해야 한다.")
    for r in rows:
        fp = os.path.join(base_dir, r['file'])
        if term_fail:
            r['terms'] = None
            continue
        if not os.path.exists(fp):
            r['terms'] = None
            term_fail.setdefault('STL 없음', f"{r['file']} 을 CSV 옆에서 찾을 수 없다.")
            continue
        try:
            m = trimesh.load(fp, force='mesh')
            m.fix_normals()
            # 내보낼 때 이미 회전시켰으므로 여기서는 +Z 가 빌드 방향이다.
            # 예측값(compute_support_volume)과 같은 조건이어야 한다.
            # 브리지 한계를 전달하지 않으면 오버행 집합이 달라져
            # 회귀 대상과 예측 대상이 어긋난다.
            r['terms'] = ga.support_terms(m, crit, brl)
        except Exception as ex:
            r['terms'] = None
            term_fail.setdefault(type(ex).__name__, f"{r['file']}: {ex}")

    P = np.array([r['pred'] for r in rows])
    Mv = np.array([r['meas'] for r in rows])

    if verbose:
        print(f"{'파일':46s} {'방향':12s} {'예측(mm³)':>12s} {'Cura(mm³)':>12s} {'비율':>7s}")
        for r in sorted(rows, key=lambda x: -x['meas']):
            ratio = r['pred'] / r['meas'] if r['meas'] > 1e-9 else float('nan')
            print(f"{r['file'][:44]:46s} {r['orientation'][:10]:12s} "
                  f"{r['pred']:12.1f} {r['meas']:12.1f} {ratio:7.2f}")

    # 상관 (순위가 맞는가)
    pear = float(np.corrcoef(P, Mv)[0, 1])
    rp, rm = np.argsort(np.argsort(P)), np.argsort(np.argsort(Mv))
    spear = float(np.corrcoef(rp, rm)[0, 1])

    # 원점을 지나는 회귀 (계통 편향)
    denom = float((P ** 2).sum())
    slope = float((P * Mv).sum() / denom) if denom > 0 else float('nan')
    resid = Mv - slope * P
    ss_tot = float(((Mv - Mv.mean()) ** 2).sum())
    r2 = 1 - float((resid ** 2).sum()) / ss_tot if ss_tot > 0 else float('nan')

    # 현재 밀도 상수를 slope 로 보정
    cur_density = PROCESS_PARAMS[ProcessType.FDM]['support_density']
    new_density = cur_density * slope

    nz = [r for r in rows if r['meas'] > 1e-9 or r['pred'] > 1e-9]
    n_zero = len(rows) - len(nz)

    def corr(d):
        p = np.array([x['pred'] for x in d]); m = np.array([x['meas'] for x in d])
        pe = float(np.corrcoef(p, m)[0, 1])
        sp = float(np.corrcoef(np.argsort(np.argsort(p)),
                               np.argsort(np.argsort(m)))[0, 1])
        return pe, sp

    print()
    print("=" * 74)
    print(f"표본 {len(rows)}건" + (f"  (양쪽 모두 0 인 행 {n_zero}건 포함)" if n_zero else ""))
    print(f"  피어슨 상관        r = {pear:+.4f}   (크기 관계)")
    print(f"  스피어만 상관      ρ = {spear:+.4f}   (순위 관계 — 방향 선택에 중요)")
    print(f"  원점 통과 회귀 기울기 = {slope:.4f}   (Cura ÷ 예측)")
    print(f"  설명력            R² = {r2:.4f}")
    if n_zero and len(nz) >= 3:
        pe2, sp2 = corr(nz)
        print()
        print(f"  0 행 {n_zero}건 제외 (n={len(nz)}) : r = {pe2:+.4f}   ρ = {sp2:+.4f}")
        print("     양쪽 모두 0 인 행은 '서포트가 필요 없다'는 판정이 일치했다는 뜻으로")
        print("     그 자체가 유효한 검증이지만, 회귀선 한쪽 끝에 몰려 상관을 부풀린다.")
        print("     두 값이 크게 다르면 상관 수치를 그대로 보고해서는 안 된다.")
    print()
    if slope > 1.02:
        print(f"  예측이 실제의 {1/slope*100:.0f}% 수준이다 (과소추정, {slope:.2f}배 보정 필요).")
    elif slope < 0.98:
        print(f"  예측이 실제의 {1/slope*100:.0f}% 수준이다 (과대추정, {slope:.2f}배 보정 필요).")
    else:
        print("  예측과 실측의 크기가 사실상 일치한다.")
    print(f"  서포트 밀도 상수 보정 제안: {cur_density:.3f} -> {new_density:.3f}")
    print("=" * 74)
    print()
    # ── 물리 모델 비교 ──
    withterms = [r for r in rows if r.get('terms')]
    if len(withterms) < 6:
        print()
        print("=" * 74)
        print("물리 모델 비교를 건너뛴다 (항 분해에 필요한 자료가 부족)")
        print("=" * 74)
        if term_fail:
            for k, v in term_fail.items():
                print(f"  [{k}] {v}")
        else:
            print(f"  분해 가능한 행 {len(withterms)}건 (6건 이상 필요)")
        print("  STL 이 measurements.csv 와 같은 폴더에 있어야 한다.")
    if len(withterms) >= 6:
        Y = np.array([r['meas'] for r in withterms])
        V = np.array([r['terms']['vol_term'] for r in withterms])
        Pm = np.array([r['terms']['perim_term'] for r in withterms])
        Ar = np.array([r['terms']['area_term'] for r in withterms])
        ss = float(((Y - Y.mean()) ** 2).sum())

        def fit(X, names, label):
            beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
            r2 = 1 - float(((Y - X @ beta) ** 2).sum()) / ss if ss > 0 else float('nan')
            k = X.shape[1]
            adj = 1 - (1 - r2) * (len(Y) - 1) / max(len(Y) - k - 1, 1)
            coef = "  ".join(f"{n}={b:+.4f}" for n, b in zip(names, beta))
            print(f"  {label:38s} R²={r2:.4f}  adjR²={adj:.4f}   {coef}")
            return r2, beta

        print()
        print("=" * 74)
        print(f"물리 모델 비교 (STL 을 다시 읽어 항을 분해, n={len(Y)})")
        print("=" * 74)
        print("  V = a·(부피항) + b·(둘레항) + c·(면적항)")
        print("     부피항 Σ(A·h)   둘레항 Σ(P·h)   면적항 ΣA   (연결 영역 단위)")
        print()
        fit(V[:, None], ['a'], "① 부피항만 (현재 공식)")
        fit(np.column_stack([V, Pm]), ['a', 'b'], "② 부피 + 둘레")
        fit(np.column_stack([V, Ar]), ['a', 'c'], "③ 부피 + 면적")
        r2_3, beta3 = fit(np.column_stack([V, Pm, Ar]), ['a', 'b', 'c'], "④ 부피 + 둘레 + 면적")
        print()
        print("  해석: ②~④ 의 R² 가 ① 보다 뚜렷이 높으면, 현재 공식에 빠진 항이 있다는 뜻이다.")
        print("        둘레항이 유의하면 지지 기둥의 바깥 벽이, 면적항이 유의하면")
        print("        모델과 닿는 인터페이스 층이 누락된 것이다.")
        print()
        print("  계수 부호를 반드시 확인한다. 재료 부피는 음수가 될 수 없으므로")
        print("  음수 계수는 항끼리 상관이 높아 회귀가 잡음을 맞추고 있다는 신호다")
        print("  (다중공선성). 그런 모델은 R² 가 높아도 채택해서는 안 된다.")
        print(f"  항 간 상관: 부피-둘레 {np.corrcoef(V,Pm)[0,1]:+.3f}  "
              f"부피-면적 {np.corrcoef(V,Ar)[0,1]:+.3f}  둘레-면적 {np.corrcoef(Pm,Ar)[0,1]:+.3f}")

        # ── 교차검증: 계수를 맞춘 자료로 성능을 말할 수는 없다 ──
        print()
        print("=" * 74)
        print("교차검증 (적합도가 아니라 예측 성능을 본다)")
        print("=" * 74)
        print("  위 R² 는 같은 자료로 계수를 맞춘 뒤 잰 값이므로 '적합도' 이지 ")
        print("  '예측 성능' 이 아니다. 계수를 모르는 자료를 얼마나 맞히는지 봐야 한다.")
        print()

        X2 = np.column_stack([V, Pm])

        # (1) Leave-One-Out
        preds = np.empty(len(Y))
        for i in range(len(Y)):
            tr = np.ones(len(Y), bool); tr[i] = False
            b_, *_ = np.linalg.lstsq(X2[tr], Y[tr], rcond=None)
            preds[i] = X2[i] @ b_
        ss = float(((Y - Y.mean()) ** 2).sum())
        q2 = 1 - float(((Y - preds) ** 2).sum()) / ss if ss > 0 else float('nan')
        print(f"  ① Leave-One-Out (한 건씩 빼고 학습)        Q² = {q2:.4f}")

        # (2) 모델 단위 분리 — 형상이 다른 부품에 일반화되는가
        def grp(name):
            base = name.split('__')[0]
            return base
        groups = np.array([grp(r['file']) for r in withterms])
        uniq = sorted(set(groups))
        if len(uniq) >= 2:
            print()
            print("  ② 모델 단위 분리 (한 부품 전체를 빼고 학습 -> 그 부품 예측)")
            print(f"     {'제외한 부품':28s} {'학습':>5s} {'평가':>5s} {'Q²':>9s} {'기울기':>8s}")
            allp, ally = [], []
            for g in uniq:
                te = groups == g
                if te.sum() < 1 or (~te).sum() < 3:
                    continue
                b_, *_ = np.linalg.lstsq(X2[~te], Y[~te], rcond=None)
                yp = X2[te] @ b_
                ssg = float(((Y[te] - Y[te].mean()) ** 2).sum())
                q2g = (1 - float(((Y[te] - yp) ** 2).sum()) / ssg) if ssg > 0 else float('nan')
                sl = float((yp * Y[te]).sum() / max((yp ** 2).sum(), 1e-9))
                allp.append(yp); ally.append(Y[te])
                print(f"     {g[:26]:28s} {int((~te).sum()):5d} {int(te.sum()):5d} "
                      f"{q2g:9.4f} {sl:8.3f}")
            if allp:
                ap = np.concatenate(allp); ay = np.concatenate(ally)
                ssa = float(((ay - ay.mean()) ** 2).sum())
                q2a = 1 - float(((ay - ap) ** 2).sum()) / ssa if ssa > 0 else float('nan')
                print(f"     {'전체 통합':28s} {'':5s} {len(ay):5d} {q2a:9.4f}")
                print()
                print("     Q² 가 위의 R² 와 비슷하면 다른 형상에도 일반화된다는 뜻이다.")
                print("     크게 낮으면 계수가 이 자료에 과적합된 것이다.")

    print()
    print("해석 기준")
    print("  ρ > 0.9  : 순위가 잘 맞는다. 방향 최적화 목적에는 충분하다.")
    print("  r  > 0.9 : 크기까지 잘 맞는다. 기울기로 상수만 보정하면 된다.")
    print("  r  < 0.7 : 공식 자체에 구조적 문제가 있다. 잔차가 큰 행을 먼저 본다.")
    print()
    print("주의 — 아래 차이는 버그가 아니다. 완전 일치를 기대하면 안 된다.")
    print("  · Cura 는 서포트 상·하면에 조밀한 인터페이스 층을 추가한다.")
    print("  · Cura 는 모델과 서포트 사이에 XY/Z 간격을 둔다.")
    print("  · Cura 는 면적이 아주 작은 서포트를 생략한다.")
    print("  · 우리 추정은 기둥을 채운 부피이고 Cura 는 격자 구조다.")
    print("  따라서 목표는 완전 일치가 아니라 (1) 순위 일치와 (2) 일정한 배율이다.")
    return {'n': len(rows), 'pearson': pear, 'spearman': spear,
            'slope': slope, 'r2': r2, 'suggested_density': new_density}


def pick_files(title, filetypes, multiple=True):
    """파일 선택 창을 띄운다. 경로를 손으로 입력할 필요를 없앤다."""
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        print("파일 선택 창을 열 수 없다(tkinter 미설치). --stl 로 경로를 직접 지정한다.")
        return []
    root = tk.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    if multiple:
        res = filedialog.askopenfilenames(title=title, filetypes=filetypes)
    else:
        r = filedialog.askopenfilename(title=title, filetypes=filetypes)
        res = (r,) if r else ()
    root.destroy()
    return [r for r in res if r]


def write_sample_stls(out_dir):
    """검증용 샘플 3종을 STL 로 저장해 대조 표본 수를 늘린다."""
    from src.core.model_loader import generate_sample_models
    src = os.path.join(out_dir, '_samples')
    os.makedirs(src, exist_ok=True)
    paths = []
    for k, d in generate_sample_models().items():
        fp = os.path.join(src, f'sample_{k}.stl')
        d['mesh'].export(fp)
        paths.append(fp)
    return paths


def open_folder(path):
    """결과 폴더를 탐색기에서 연다."""
    try:
        full = os.path.abspath(path)
        if sys.platform.startswith('win'):
            os.startfile(full)
        elif sys.platform == 'darwin':
            os.system(f'open "{full}"')
    except Exception:
        pass


def explain(stl_path, process='FDM', printer=(300, 300, 340)):
    """왜 인쇄 불가로 판정됐는지 근거 수치를 보여준다."""
    mesh = trimesh.load(stl_path, force='mesh')
    mesh.fix_normals()
    engine = AMRuleEngine()
    P = PROCESS_PARAMS[ProcessType[process]]

    print(f"파일 : {os.path.basename(stl_path)}")
    print(f"메시 : 면 {len(mesh.faces):,}개 · 정점 {len(mesh.vertices):,}개 · "
          f"부피 {mesh.volume:,.1f}mm³ · 크기 {np.round(mesh.extents,1).tolist()}")
    print(f"       닫힘={mesh.is_watertight} · 법선일관={mesh.is_winding_consistent} · "
          f"바디={getattr(mesh,'body_count',1)}")
    print()

    wt = ga.compute_wall_thickness(mesh)
    if wt.get('available'):
        t = np.asarray(wt['thicknesses'])
        print(f"벽두께 분포 (샘플 {wt['samples']}개, 공정 물리 하한 {P['hard_wall']}mm)")
        for q in (0, 1, 5, 25, 50, 100):
            v = np.percentile(t, q)
            print(f"   {q:3d}퍼센타일 {v:9.4f} mm")
        n_below = int((t < P['hard_wall']).sum())
        print(f"   하한 미만 샘플 {n_below} / {len(t)}")
        if n_below:
            print(f"   가장 얇은 값들: " +
                  ", ".join(f"{v:.4f}" for v in np.sort(t)[:min(10, n_below)]))
            print()
            print("   해석: 얇은 값이 여러 개면 실제 미세 형상일 가능성이 높다.")
            print("         한두 개뿐이고 나머지와 크게 동떨어져 있으면 측정 이상치를 의심한다.")
    else:
        print(f"벽두께 측정 불가: {wt.get('reason')}")

    print()
    r = engine.evaluate(mesh, process, (0, 0, 1), printer)
    print("게이트 판정")
    for g in r.gates:
        print(f"   [{'통과' if g.passed else '위반'}] {g.name}")
        print(f"          {g.detail}")
    print()
    print(f"결과 : feasible={r.feasible} · 점수={r.total_score} · 등급={r.grade}")


def main():
    ap = argparse.ArgumentParser(description="Cura 대조 외부 검증 도구")
    sub = ap.add_subparsers(dest='cmd', required=True)

    e = sub.add_parser('export', help='방향별 STL 과 기록표 생성')
    e.add_argument('--stl', nargs='*', default=None,
                   help='생략하면 파일 선택 창이 열린다')
    e.add_argument('--no-samples', action='store_true',
                   help='샘플 모델 3종을 함께 내보내지 않는다')
    e.add_argument('--out', default='cura_run')
    e.add_argument('--process', default='FDM')
    e.add_argument('--printer', nargs=3, type=float, default=[300, 300, 340],
                   help='빌드 볼륨 X Y Z (기본: Ender-3 Max)')

    d_ = sub.add_parser('why', help='특정 STL 이 왜 인쇄 불가로 판정됐는지 설명')
    d_.add_argument('--stl', nargs='?', default=None)
    d_.add_argument('--process', default='FDM')
    d_.add_argument('--printer', nargs=3, type=float, default=[300, 300, 340])

    a = sub.add_parser('analyze', help='기록표 분석')
    a.add_argument('--csv', nargs='?', default=None,
                   help='생략하면 파일 선택 창이 열린다')
    a.add_argument('--filament', type=float, default=1.75)

    args = ap.parse_args()

    if args.cmd == 'export':
        paths = list(args.stl or [])
        if not paths:
            picked = pick_files("슬라이싱할 STL 파일을 고르세요 (여러 개 선택 가능)",
                                [("STL 파일", "*.stl"), ("모든 파일", "*.*")])
            paths = list(picked)
        if not paths and args.no_samples:
            print("선택된 파일이 없다. 종료한다.")
            return
        if not args.no_samples:
            paths += write_sample_stls(args.out)
        if not paths:
            print("내보낼 모델이 없다. 종료한다.")
            return
        csv_path = export(paths, args.out, args.process, tuple(args.printer))
        open_folder(args.out)
        print()
        print("다음 순서")
        print("  1) 열린 폴더의 STL 을 Cura 로 하나씩 불러온다 (모델을 회전시키지 말 것)")
        print("  2) 서포트 OFF 로 Slice -> 필라멘트 길이(m) 를 적는다")
        print("  3) 서포트 ON  으로 Slice -> 필라멘트 길이(m) 를 적는다")
        print("  4) measurements.csv 에 두 값을 채운다")
        print("  5) 5_CURA_ANALYZE.bat 을 실행한다")
    elif args.cmd == 'why':
        path = args.stl
        if not path:
            picked = pick_files("진단할 STL 을 고르세요",
                                [("STL 파일", "*.stl"), ("모든 파일", "*.*")], multiple=False)
            path = picked[0] if picked else None
        if not path:
            print("선택된 파일이 없다. 종료한다.")
            return
        explain(path, args.process, tuple(args.printer))

    else:
        csv_path = args.csv
        if not csv_path:
            picked = pick_files("작성한 measurements.csv 를 고르세요",
                                [("CSV 파일", "*.csv"), ("모든 파일", "*.*")],
                                multiple=False)
            csv_path = picked[0] if picked else None
        if not csv_path:
            print("선택된 파일이 없다. 종료한다.")
            return
        analyze(csv_path, args.filament)


if __name__ == '__main__':
    main()
