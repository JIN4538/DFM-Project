"""AM-DFM Evaluator — Streamlit 웹 애플리케이션 (v2)

v1 대비 주요 변경
-----------------
1. 평가 시점의 설정(공정/방향/프린터/단위)을 결과와 함께 저장하고 그것만 표시한다.
   v1은 결과는 이전 값, 표시는 현재 위젯 값이라 사이드바만 만지면
   화면의 '빌드 방향'이 실제 계산과 달라졌다.
2. 3D 뷰어 facecolor 를 Plotly가 받는 색 문자열 배열로 넘긴다.
   v1은 0~1 실수 배열을 넘겨서 오버행 하이라이트가 렌더링되지 않을 수 있었다.
3. 하드 게이트 결과와 메시 진단 경고를 최상단에 표시한다.
4. STL 단위 선택 UI를 추가했다(STL 파일에는 단위 정보가 없다).
5. 방향 비교를 6방향으로 하고, 결과를 한 번만 계산해 재사용한다.
   v1은 evaluate_all_orientations + find_optimal_orientation 로 6회 중복 평가했다.
6. N/A 규칙을 100점이 아니라 N/A로 표시하고 가중치 재분배를 명시한다.
7. 가중치 민감도 분석 버튼을 추가했다(가중치 근거가 임의라는 한계 대응).
"""

import os
import sys
import tempfile
import inspect

import numpy as np
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.model_loader import load_model, generate_sample_models, diagnose, UNIT_SCALE
from src.core.scoring import (evaluate_orientations, pick_best, results_to_rows,
                              sensitivity_analysis, pareto_front, AXIS_ORIENTATIONS)
from src.core import geometry_analyzer as ga
from src.core.weights import ahp, pair_list, SAATY_SCALE, compare_weight_sets
from src.processes.additive import (AMRuleEngine, PROCESS_PARAMS, ProcessType,
                                     PROCESS_TERMS, process_label, BASE_WEIGHTS,
                                     RULE_LABELS)

st.set_page_config(page_title="AM-DFM Evaluator v2", page_icon="🔧",
                   layout="wide", initial_sidebar_state="expanded")

for k in ('result', 'ctx', 'orient', 'sens', 'ahp'):
    st.session_state.setdefault(k, None)


# ──────────────────────────────────────────────────────────────
def render_3d(mesh, build_direction, overhang_faces=None):
    """빌드 좌표계로 회전한 메시를 그린다. 화면의 위쪽이 항상 적층 방향이다."""
    m = ga.to_build_frame(mesh, build_direction)
    v, f = m.vertices, m.faces
    base, hot = 'rgb(90,140,205)', 'rgb(225,60,55)'
    colors = np.array([base] * len(f), dtype=object)
    if overhang_faces:
        idx = np.asarray(overhang_faces, dtype=int)
        colors[idx[idx < len(f)]] = hot
    fig = go.Figure(go.Mesh3d(
        x=v[:, 0], y=v[:, 1], z=v[:, 2],
        i=f[:, 0], j=f[:, 1], k=f[:, 2],
        facecolor=colors.tolist(), flatshading=True,
        lighting=dict(ambient=.55, diffuse=.8, specular=.15),
    ))
    fig.update_layout(scene=dict(xaxis_title='X (mm)', yaxis_title='Y (mm)',
                                 zaxis_title='빌드 방향 (mm)', aspectmode='data'),
                      margin=dict(l=0, r=0, t=28, b=0), height=460,
                      title="빌드 좌표계 (빨강 = 지지구조 필요 면)")
    return fig


def render_gauge(score, grade):
    color = {'A': '#27ae60', 'B': '#2ecc71', 'C': '#f39c12',
             'D': '#e67e22', 'F': '#e74c3c'}.get(grade, '#95a5a6')
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=score,
        title={'text': f"등급 {grade}", 'font': {'size': 22}},
        gauge={'axis': {'range': [0, 100]}, 'bar': {'color': color, 'thickness': .6},
               'steps': [{'range': [0, 60], 'color': '#fdeaea'},
                         {'range': [60, 80], 'color': '#fdf4d8'},
                         {'range': [80, 100], 'color': '#e3f4e6'}]},
        number={'font': {'size': 40}}))
    fig.update_layout(height=260, margin=dict(l=30, r=30, t=50, b=0))
    return fig


def render_radar(rules):
    scored = [r for r in rules if r.score is not None]
    if len(scored) < 3:
        return None
    names = [r.label.split(' (')[0] for r in scored]
    vals = [r.score for r in scored]
    fig = go.Figure(go.Scatterpolar(r=vals + [vals[0]], theta=names + [names[0]],
                                    fill='toself', line=dict(color='#2980b9', width=2),
                                    fillcolor='rgba(41,128,185,.2)'))
    fig.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                      showlegend=False, height=380, title="규칙별 점수 (N/A 규칙 제외)")
    return fig


# ──────────────────────────────────────────────────────────────
# AHP — 쌍대비교로 가중치 도출
# ──────────────────────────────────────────────────────────────
AHP_ITEMS = ['wall_thickness', 'overhang_area', 'support_volume',
             'aspect_ratio', 'build_margin']


def render_ahp():
    st.markdown("---")
    st.subheader("가중치 도출 (AHP 쌍대비교)")
    st.caption("현재 가중치는 판단으로 정한 값입니다. 두 항목씩 비교하면 "
               "가중치를 산출하고 응답의 논리적 일관성까지 검증할 수 있습니다. "
               "5개 항목이므로 10번만 비교하면 됩니다.")

    with st.expander("쌍대비교 설문 열기", expanded=False):
        st.caption("각 쌍에서 어느 쪽이 제조성 판단에 더 중요한지, 얼마나 더 중요한지 고르세요.")
        pairs = pair_list(AHP_ITEMS)
        comps = {}
        for i, (a, b) in enumerate(pairs):
            la = RULE_LABELS[a].split(' (')[0]
            lb = RULE_LABELS[b].split(' (')[0]
            st.markdown(f"**{i+1}. {la}  vs  {lb}**")
            c1, c2 = st.columns([1, 1])
            side = c1.radio("더 중요한 쪽", [la, "동등", lb],
                            index=1, key=f"ahp_side_{i}", horizontal=True,
                            label_visibility="collapsed")
            if side == "동등":
                comps[(a, b)] = 1.0
                c2.caption("동등하게 중요")
            else:
                lvl = c2.select_slider(
                    "정도", options=list(SAATY_SCALE), value=3,
                    format_func=lambda v: f"{v} · {SAATY_SCALE[v]}",
                    key=f"ahp_lvl_{i}", label_visibility="collapsed")
                comps[(a, b)] = float(lvl) if side == la else 1.0 / float(lvl)
            st.divider()

        if st.button("가중치 계산", type="primary"):
            try:
                st.session_state.ahp = ahp(AHP_ITEMS, comps)
            except Exception as e:
                st.error(f"계산 실패: {e}")

    res = st.session_state.get('ahp')
    if not res:
        return

    cr = res['consistency_ratio']
    m = st.columns(3)
    m[0].metric("일관성 비율 CR", f"{cr:.4f}")
    m[1].metric("판정", "일관됨" if res['consistent'] else "재검토 필요")
    m[2].metric("최대 고윳값", f"{res['lambda_max']:.4f}")
    if res['consistent']:
        st.success("CR이 0.10 미만이므로 응답이 논리적으로 일관됩니다. 가중치를 채택할 수 있습니다.")
    else:
        st.warning("CR이 0.10 이상입니다. 응답에 모순이 있습니다"
                   "(예: A>B, B>C 인데 C>A). 몇 개 문항을 재검토하세요.")

    rows = compare_weight_sets({
        '현재(판단)': {k: BASE_WEIGHTS[k] for k in AHP_ITEMS},
        'AHP(고유벡터)': res['weights'],
        'AHP(기하평균)': res['weights_geometric'],
    })
    for r in rows:
        r['규칙'] = RULE_LABELS.get(r['규칙'], r['규칙']).split(' (')[0]
    st.dataframe(rows, use_container_width=True, hide_index=True)
    st.caption("두 AHP 산출법의 결과가 비슷하면 계산이 안정적이라는 뜻입니다. "
               "'현재'와 차이가 크다면 판단 근거를 재검토할 근거가 됩니다. "
               "여러 명에게 받은 뒤 기하평균으로 종합하는 것이 표준 절차입니다.")


# ──────────────────────────────────────────────────────────────
# 소스코드 뷰어 — 지금 실행 중인 코드를 그대로 보여준다
# ──────────────────────────────────────────────────────────────
def _key_functions():
    """미팅에서 자주 물어볼 핵심 함수들."""
    from src.processes import additive as ad
    return {
        "① 오버행 판정 — compute_overhang": ga.compute_overhang,
        "② 빌드 좌표계 변환 — to_build_frame": ga.to_build_frame,
        "③ 지지구조물 부피 — compute_support_volume": ga.compute_support_volume,
        "④ 벽두께 측정 — compute_wall_thickness": ga.compute_wall_thickness,
        "⑤ 종횡비 — compute_aspect_ratio": ga.compute_aspect_ratio,
        "⑥ 점수 함수(작을수록 좋음) — score_at_most": ad.score_at_most,
        "⑦ 점수 함수(클수록 좋음) — score_at_least": ad.score_at_least,
        "⑧ 하드 게이트 — _run_gates": ad.AMRuleEngine._run_gates,
        "⑨ 가중치 재정규화 — _normalize_weights": ad.AMRuleEngine._normalize_weights,
    }


def _source_files():
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    rel = ['src/core/geometry_analyzer.py', 'src/processes/additive.py',
           'src/core/scoring.py', 'src/core/model_loader.py',
           'src/ui/app.py', 'verify.py', 'requirements.txt']
    return {r: os.path.join(root, *r.split('/')) for r in rel}


def render_source_viewer():
    st.markdown("---")
    with st.expander("💻 소스코드 보기 (지금 실행 중인 코드)", expanded=False):
        tab1, tab2 = st.tabs(["핵심 함수", "전체 파일"])

        with tab1:
            funcs = _key_functions()
            pick = st.selectbox("함수 선택", list(funcs), key="src_fn")
            fn = funcs[pick]
            try:
                src = inspect.getsource(fn)
                file = inspect.getsourcefile(fn)
                line = inspect.getsourcelines(fn)[1]
                st.caption(f"{os.path.basename(file)} : {line}행")
                st.code(src, language='python')
            except Exception as e:
                st.error(f"소스를 읽을 수 없습니다: {e}")

        with tab2:
            files = _source_files()
            pick = st.selectbox("파일 선택", list(files), key="src_file")
            try:
                with open(files[pick], encoding='utf-8') as fh:
                    text = fh.read()
                st.caption(f"{files[pick]}  ·  {len(text.splitlines())}행")
                st.code(text, language='python')
            except Exception as e:
                st.error(f"파일을 읽을 수 없습니다: {e}")


# ──────────────────────────────────────────────────────────────
def main():
    with st.sidebar:
        st.title("🔧 AM-DFM Evaluator")
        st.caption("v2 · 하드 게이트 + 소프트 점수")
        st.markdown("---")

        st.subheader("모델 입력")
        source = st.radio("입력 방식", ["샘플 모델", "STL 업로드"], index=0)
        mesh, model_name, warns = None, "", []

        if source == "샘플 모델":
            samples = generate_sample_models()
            keys = list(samples)
            key = st.selectbox("샘플 선택", keys,
                               format_func=lambda k: samples[k]['name'])
            mesh, model_name = samples[key]['mesh'], samples[key]['name']
            st.caption(samples[key]['description'])
            warns = diagnose(mesh)
        else:
            unit = st.selectbox("파일 단위", list(UNIT_SCALE), index=0,
                                help="STL 파일에는 단위 정보가 없습니다. 잘못 고르면 모든 임계값이 어긋납니다. "
                                     "근거: KS D ISO/ASTM 52910 7.10 (STL 단위 부재로 인한 크기 오류)")
            up = st.file_uploader("STL 파일", type=['stl'])
            if up is not None:
                with tempfile.NamedTemporaryFile(suffix='.stl', delete=False) as fh:
                    fh.write(up.getvalue()); tmp = fh.name
                try:
                    d = load_model(tmp, unit=unit)
                    mesh, model_name, warns = d['mesh'], d['metadata']['filename'], d['warnings']
                except Exception as e:
                    st.error(f"로드 실패: {e}")
                finally:
                    os.unlink(tmp)

        st.markdown("---")
        st.subheader("공정 및 장비")
        process = st.selectbox(
            "공정", [p.value for p in ProcessType], index=0,
            format_func=lambda v: process_label(v, short=True),
            help="FDM·SLA·SLS 등은 상표에서 유래한 통칭입니다. "
                 "괄호 안이 KS D ISO/ASTM 52910 3.1절의 표준 용어입니다.")
        ptype = ProcessType[process]
        P = PROCESS_PARAMS[ptype]
        T = PROCESS_TERMS[ptype]
        st.caption(f"표준 용어: {T['std_ko']} ({T['std_en']}) — 52910 {T['clause']}")
        st.caption(f"임계각 {P['critical_angle']:.0f}° · 권장 벽두께 {P['thr_wall']}mm · "
                   f"물리 하한 {P['hard_wall']}mm · 서포트 밀도 {P['support_density']*100:.0f}%")
        st.caption(f"수치 출처: {P['source']}")

        bdir_label = st.selectbox("빌드 방향", list(AXIS_ORIENTATIONS), index=0)
        build_direction = AXIS_ORIENTATIONS[bdir_label]

        c1, c2, c3 = st.columns(3)
        px = c1.number_input("X", value=250, min_value=10)
        py = c2.number_input("Y", value=250, min_value=10)
        pz = c3.number_input("Z", value=250, min_value=10)
        printer = (float(px), float(py), float(pz))

        mf_on = st.checkbox("정밀 최소특징 검사 (복셀, 느림)", value=False,
                            help="끄면 해당 규칙은 N/A 이고 가중치가 재분배됩니다.")
        tg_on = st.checkbox("두께 변화 검사 (오탐 있음)", value=False,
                            help="단순 솔리드에서 오탐이 납니다. 40x30x20 직육면체는 "
                                 "두께 급변이 없으나 측정 방향에 따라 비 2.0 이 나옵니다. "
                                 "급변 유무 확인용으로만 켜세요.")

        st.markdown("---")
        run = st.button("🔍 제조성 평가", type="primary", use_container_width=True,
                        disabled=(mesh is None))

    st.title("적층제조 제조성 검토 (DfAM)")
    st.caption("KS D ISO/ASTM 52910 (ISO/ASTM 52910:2018 IDT) 기반 프레임워크 · "
               "공정별 수치는 표준 범위 밖이므로 별도 출처를 명시합니다")

    if mesh is None:
        st.info("사이드바에서 모델을 선택하거나 STL을 업로드하세요.")
        render_source_viewer()
        return

    for w in warns:
        st.warning(f"메시 진단: {w}")

    ext = mesh.extents
    c = st.columns(5)
    c[0].metric("부피 (mm³)", f"{mesh.volume:,.1f}")
    c[1].metric("표면적 (mm²)", f"{mesh.area:,.1f}")
    c[2].metric("치수 (mm)", f"{ext[0]:.1f}×{ext[1]:.1f}×{ext[2]:.1f}")
    c[3].metric("면 / 정점", f"{len(mesh.faces):,} / {len(mesh.vertices):,}")
    c[4].metric("닫힌 메시", "예" if mesh.is_watertight else "아니오")

    if run:
        with st.spinner("평가 중..."):
            engine = AMRuleEngine()
            res = engine.evaluate(mesh, process, build_direction, printer,
                                  min_feature_enabled=mf_on,
                                  thickness_gradient_enabled=tg_on)
            st.session_state.result = res
            # 결과와 함께 '그때의 설정'을 저장한다 (표시 불일치 방지)
            st.session_state.ctx = dict(model=model_name, process=process,
                                        bdir_label=bdir_label, bdir=build_direction,
                                        printer=printer, mf=mf_on, tg=tg_on)
            st.session_state.orient = None
            st.session_state.sens = None

    res, ctx = st.session_state.result, st.session_state.ctx
    if res is None:
        st.info("좌측에서 평가를 실행하세요.")
        render_source_viewer()
        return

    stale = (ctx['model'] != model_name or ctx['process'] != process
             or ctx['bdir_label'] != bdir_label or ctx['printer'] != printer
             or ctx['mf'] != mf_on or ctx.get('tg') != tg_on)
    if stale:
        st.warning("사이드바 설정이 바뀌었습니다. 아래 결과는 **이전 설정** 기준입니다 — "
                   "다시 평가하려면 [제조성 평가]를 누르세요.")

    st.markdown("---")
    st.subheader(f"결과 — {ctx['model']} / {process_label(ctx['process'], short=True)} "
                 f"/ 빌드 방향 {ctx['bdir_label']}")

    # 하드 게이트
    st.markdown("**1단계 · 하드 게이트 (물리적 인쇄 가능성)**")
    gc = st.columns(len(res.gates))
    for col, g in zip(gc, res.gates):
        col.markdown(f"{'✅' if g.passed else '⛔'} **{g.name}**")
        col.caption(g.detail)
        if g.clause:
            col.caption(f"근거: KS D ISO/ASTM 52910 {g.clause}")

    if not res.feasible:
        st.error(f"**인쇄 불가** — {res.summary}")
        for s in res.suggestions:
            st.info(s)
        st.caption("하드 제약을 위반하면 품질 점수를 산출하지 않습니다. "
                   "가중 평균에 섞으면 인쇄 불가 부품이 높은 등급을 받을 수 있기 때문입니다.")
        render_source_viewer()
        return

    # 소프트 점수
    st.markdown("**2단계 · 품질 점수**")
    a, b = st.columns([1, 2])
    with a:
        st.markdown(f"## {res.total_score}점 · {res.grade}등급")
        na = [r for r in res.rule_results if r.score is None]
        st.caption(f"평가 규칙 {len(res.rule_results)-len(na)}개"
                   + (f" · N/A {len(na)}개 (가중치 재분배됨)" if na else ""))
    with b:
        st.plotly_chart(render_gauge(res.total_score, res.grade), use_container_width=True)

    oh_rule = next((r for r in res.rule_results if r.rule_name == 'overhang_area'), None)
    st.plotly_chart(render_3d(mesh, ctx['bdir'],
                              oh_rule.problem_face_indices if oh_rule else None),
                    use_container_width=True)

    radar = render_radar(res.rule_results)
    if radar:
        st.plotly_chart(radar, use_container_width=True)

    st.subheader("규칙별 상세")
    icon = {'pass': '✅', 'warn': '⚠️', 'fail': '❌', 'na': '➖'}
    for r in res.rule_results:
        c1, c2, c3 = st.columns([3, 3, 1])
        c1.markdown(f"{icon[r.status]} **{r.label}**")
        c1.caption(f"가중치 {r.weight*100:.1f}%" if r.score is not None else "가중치 재분배됨")
        if r.clause:
            c1.caption(f"근거 조항: {r.clause}")
        c2.markdown(f"`{r.value}` {r.unit}" + (f" / 기준 `{r.threshold}`" if r.threshold else ""))
        c2.caption(r.detail)
        if r.score is None:
            c3.markdown("### N/A")
        else:
            c3.markdown(f"### {r.score:.0f}")
            c3.progress(min(r.score, 100) / 100)

    st.subheader("개선 제안")
    for s in res.suggestions:
        (st.success if "충족" in s else st.warning)(s)

    # 방향 비교 (한 번만 계산해서 캐시)
    st.markdown("---")
    st.subheader("빌드 방향 비교 (6방향)")
    if st.button("6방향 비교 실행"):
        with st.spinner("6방향 평가 중..."):
            st.session_state.orient = evaluate_orientations(
                mesh, ctx['process'], ctx['printer'], min_feature_enabled=ctx['mf'])
    if st.session_state.orient:
        rows = results_to_rows(st.session_state.orient)
        st.dataframe(rows, use_container_width=True, hide_index=True)
        best = pick_best(st.session_state.orient)
        if best['best_orientation']:
            st.success(f"🏆 최적 빌드 방향: **{best['best_orientation']}** — "
                       f"{best['best_score']}점 ({best['best_grade']}등급) · "
                       f"인쇄 가능 방향 {best['feasible_count']}/6")
        else:
            st.error(best['note'])
        pf = pareto_front(st.session_state.orient)
        if pf.get('weight_free'):
            st.info(f"**가중치 검증** — 가중합 1위({pf['best_by_weights']})가 나머지 방향을 "
                    f"모든 규칙에서 지배합니다. 지배 관계가 성립하면 어떤 양수 가중치를 써도 "
                    f"순위가 바뀌지 않으므로, 이 선택에는 가중치가 필요하지 않습니다.")
        else:
            st.warning(f"**가중치 검증** — 파레토 최적 방향이 {len(pf['front'])}개"
                       f"({', '.join(pf['front'])})이며 서로 지배하지 않습니다. "
                       f"트레이드오프가 있으므로 하나를 고르려면 선호 정보(가중치)가 필요하고, "
                       f"이 경우 가중치의 근거가 결과를 좌우합니다.")
        st.caption("v1은 X/Y/Z 3방향만 비교했습니다. +Z와 -Z는 부품을 뒤집는 것이라 "
                   "오버행 분포가 완전히 다릅니다.")

    # 민감도 분석
    st.markdown("---")
    st.subheader("가중치 민감도 분석")
    st.caption("가중치는 현재 임의 설정입니다. ±50% 무작위 교란 200회로 등급이 얼마나 바뀌는지 봅니다.")
    if st.button("민감도 분석 실행"):
        with st.spinner("200회 반복 평가 중..."):
            st.session_state.sens = sensitivity_analysis(
                mesh, ctx['process'], ctx['bdir'], ctx['printer'])
    if st.session_state.sens:
        s = st.session_state.sens
        if 'base_score' in s:
            m = st.columns(4)
            m[0].metric("기준 점수", f"{s['base_score']} ({s['base_grade']})")
            m[1].metric("점수 범위", f"{s['score_min']:.1f} ~ {s['score_max']:.1f}")
            m[2].metric("표준편차", f"{s['score_std']:.2f}")
            m[3].metric("등급 변동률", f"{s['grade_changed_ratio']*100:.1f}%",
                        help="가중치를 흔들었을 때 등급이 바뀐 비율")
            st.metric("등급 경계까지 거리", f"{s['boundary_distance']:.1f}점")
            if s['boundary_distance'] > 4.0 and s['grade_changed_ratio'] < 0.05:
                st.warning("변동률이 낮지만 이 부품은 등급 경계에서 멀리 떨어져 있습니다. "
                           "경계 근처 부품은 변동률이 훨씬 커지므로, 이 수치만으로 "
                           "가중치가 강건하다고 결론지을 수 없습니다.")
            else:
                st.caption("등급 경계에 가까울수록 가중치의 영향이 커집니다.")
        else:
            st.info(s.get('note', ''))

    render_ahp()

    render_source_viewer()

    st.markdown("---")
    st.caption("AM-DFM Evaluator v2 · KS D ISO/ASTM 52910(2024 확인) 프레임워크 "
               "(ISO/ASTM 52910:2018 IDT) · "
               "Ref: Oh, Ko, Sprock, Bernstein & Kwon (2021), Additive Manufacturing, 37, 101702")


if __name__ == "__main__":
    main()
