"""평가 결과 관리 및 빌드 방향 탐색 (v2)

v1 대비 주요 변경
-----------------
1. 방향 후보가 3개(X, Y, Z)가 아니라 6개(±X, ±Y, ±Z)이다.
   +Z와 -Z는 부품을 뒤집는 것이라 오버행 분포가 완전히 달라진다.
   v1은 축 정렬 방향의 절반만 보고 있었다.
2. find_optimal_orientation 이 evaluate_all_orientations 를 다시 호출하지 않는다.
   v1은 두 함수를 연달아 호출해 같은 평가를 6회(3방향 x 2) 중복 수행했다.
3. 인쇄 불가(하드 게이트 위반) 방향은 후보에서 제외한다.
4. 임의 방향 리스트를 주입할 수 있어 향후 GA 도입 시 그대로 재사용된다.
"""

from typing import Dict, List, Optional

import numpy as np
import trimesh

from src.processes.additive import AMRuleEngine, EvaluationResult

AXIS_ORIENTATIONS = {
    '+Z (기본)': (0, 0, 1),
    '-Z (뒤집기)': (0, 0, -1),
    '+X': (1, 0, 0),
    '-X': (-1, 0, 0),
    '+Y': (0, 1, 0),
    '-Y': (0, -1, 0),
}


def evaluate_orientations(mesh: trimesh.Trimesh, process_type='FDM',
                          printer_dims=(250, 250, 250),
                          orientations: Optional[Dict] = None,
                          min_feature_enabled=False) -> Dict[str, EvaluationResult]:
    """주어진 방향들에 대해 한 번씩만 평가한다."""
    engine = AMRuleEngine()
    orientations = orientations or AXIS_ORIENTATIONS
    return {label: engine.evaluate(mesh, process_type, d, printer_dims,
                                   min_feature_enabled=min_feature_enabled)
            for label, d in orientations.items()}


def pick_best(results: Dict[str, EvaluationResult]) -> dict:
    """이미 계산된 결과에서 최적 방향을 고른다 (재평가하지 않는다)."""
    feasible = {k: v for k, v in results.items() if v.feasible and v.total_score is not None}
    if not feasible:
        return {'best_orientation': None, 'best_score': None, 'best_grade': None,
                'feasible_count': 0, 'note': '모든 방향에서 하드 제약을 위반했습니다.'}
    best = max(feasible.items(), key=lambda kv: kv[1].total_score)
    return {'best_orientation': best[0], 'best_score': best[1].total_score,
            'best_grade': best[1].grade, 'feasible_count': len(feasible),
            'note': ''}


def find_optimal_orientation(mesh, process_type='FDM', printer_dims=(250, 250, 250),
                             orientations=None, min_feature_enabled=False) -> dict:
    results = evaluate_orientations(mesh, process_type, printer_dims,
                                    orientations, min_feature_enabled)
    out = pick_best(results)
    out['all_results'] = results
    return out


def results_to_rows(results: Dict[str, EvaluationResult]) -> List[dict]:
    """방향별 비교 표. 규칙이 행, 방향이 열."""
    labels = list(results.keys())
    first = next(iter(results.values()))
    rows = []
    for i, rr in enumerate(first.rule_results):
        row = {'규칙': rr.label}
        for lb in labels:
            r = results[lb].rule_results[i]
            row[lb] = 'N/A' if r.score is None else round(r.score, 1)
        rows.append(row)

    row = {'규칙': '인쇄 가능 여부'}
    for lb in labels:
        row[lb] = 'O' if results[lb].feasible else 'X 불가'
    rows.append(row)

    row = {'규칙': '종합 점수'}
    for lb in labels:
        r = results[lb]
        row[lb] = '-' if r.total_score is None else f"{r.total_score} ({r.grade})"
    rows.append(row)
    return rows


def sensitivity_analysis(mesh, process_type='FDM', build_direction=(0, 0, 1),
                         printer_dims=(250, 250, 250), delta=0.5, seed=0,
                         n_trials=200) -> dict:
    """가중치 민감도 분석.

    각 가중치를 +-delta 비율로 무작위 교란한 뒤 등급이 얼마나 바뀌는지 본다.
    가중치를 evaluate 인자로 주입하므로 전역 상태를 수정하지 않는다.

    주의: 등급 변동률은 부품이 등급 경계에서 얼마나 떨어져 있는지에 크게
    좌우된다. 경계에서 먼 부품은 변동률이 0에 가깝게 나오므로, 이 수치만으로
    '가중치가 강건하다'고 결론지으면 안 된다. boundary_distance 를 함께 본다.
    """
    from src.processes.additive import BASE_WEIGHTS

    engine = AMRuleEngine()
    base = engine.evaluate(mesh, process_type, build_direction, printer_dims)
    if base.total_score is None:
        return {'base': base, 'note': '인쇄 불가 부품이라 민감도 분석 대상이 아닙니다.'}

    rng = np.random.default_rng(seed)
    original = dict(BASE_WEIGHTS)
    scores, grades = [], []
    for _ in range(n_trials):
        w = {k: v * (1.0 + rng.uniform(-delta, delta)) for k, v in original.items()}
        tot = sum(w.values())
        w = {k: v / tot for k, v in w.items()}
        r = engine.evaluate(mesh, process_type, build_direction, printer_dims, weights=w)
        if r.total_score is None:
            continue
        scores.append(r.total_score)
        grades.append(r.grade)

    scores = np.array(scores, dtype=float)
    boundaries = (60.0, 70.0, 80.0, 90.0)
    dist = min(abs(base.total_score - b) for b in boundaries)
    return {
        'base_score': base.total_score, 'base_grade': base.grade,
        'score_min': float(scores.min()), 'score_max': float(scores.max()),
        'score_std': float(scores.std()),
        'grade_changed_ratio': float(np.mean([g != base.grade for g in grades])),
        'boundary_distance': float(dist),
        'delta': delta, 'n_trials': len(scores),
    }


def pareto_front(results: Dict[str, EvaluationResult]) -> dict:
    """가중치 없이 방향을 고를 수 있는지 본다.

    방향 A가 방향 B를 모든 규칙에서 같거나 낫고 최소 하나에서 더 나으면
    A가 B를 지배한다. 지배 관계가 성립하면 어떤 양수 가중치를 써도 순위가
    바뀌지 않으므로, 그 선택에는 가중치가 필요하지 않다.
    """
    feas = {k: v for k, v in results.items()
            if v.feasible and v.total_score is not None}
    if len(feas) < 2:
        return {'front': list(feas), 'weight_free': True,
                'note': '비교 대상이 부족합니다.'}

    names = [r.rule_name for r in next(iter(feas.values())).rule_results
             if r.score is not None]
    V = {k: np.array([next(x.score for x in v.rule_results if x.rule_name == n)
                      for n in names]) for k, v in feas.items()}

    def dominates(a, b):
        return bool(np.all(a >= b - 1e-9) and np.any(a > b + 1e-9))

    labels = list(feas)
    front = [a for a in labels
             if not any(dominates(V[b], V[a]) for b in labels if b != a)]
    best_w = max(labels, key=lambda l: feas[l].total_score)
    weight_free = all(
        dominates(V[best_w], V[b]) or np.allclose(V[best_w], V[b])
        for b in labels if b != best_w)
    return {
        'front': front, 'best_by_weights': best_w, 'weight_free': weight_free,
        'rules': names,
        'note': ('가중합 1위가 나머지를 모두 지배하므로 이 선택에는 가중치가 '
                 '필요하지 않습니다.' if weight_free else
                 f'트레이드오프가 있어 파레토 최적 {len(front)}개 중 선택하려면 '
                 f'선호 정보(가중치 등)가 필요합니다.'),
    }
