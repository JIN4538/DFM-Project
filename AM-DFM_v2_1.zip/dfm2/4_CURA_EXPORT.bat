@echo off
cd /d "%~dp0"
title AM-DFM  -  Step 4 : Export STL for Cura
echo ==================================================
echo   Step 4 : Export oriented STL files for Cura
echo.
echo   A file dialog will open.
echo   Pick your NIST artifact STL (or Cancel to use
echo   only the 3 built-in sample models).
echo ==================================================
echo.

set "CONDA_BAT="
if exist "%USERPROFILE%\anaconda3\Scripts\activate.bat" set "CONDA_BAT=%USERPROFILE%\anaconda3\Scripts\activate.bat"
if exist "%USERPROFILE%\miniconda3\Scripts\activate.bat" set "CONDA_BAT=%USERPROFILE%\miniconda3\Scripts\activate.bat"
if exist "%LOCALAPPDATA%\anaconda3\Scripts\activate.bat" set "CONDA_BAT=%LOCALAPPDATA%\anaconda3\Scripts\activate.bat"
if exist "%LOCALAPPDATA%\miniconda3\Scripts\activate.bat" set "CONDA_BAT=%LOCALAPPDATA%\miniconda3\Scripts\activate.bat"
if exist "C:\ProgramData\anaconda3\Scripts\activate.bat" set "CONDA_BAT=C:\ProgramData\anaconda3\Scripts\activate.bat"
if exist "C:\ProgramData\miniconda3\Scripts\activate.bat" set "CONDA_BAT=C:\ProgramData\miniconda3\Scripts\activate.bat"
if exist "C:\Anaconda3\Scripts\activate.bat" set "CONDA_BAT=C:\Anaconda3\Scripts\activate.bat"

if not defined CONDA_BAT (
    echo [ERROR] Anaconda / Miniconda not found.
    echo Please run this from Anaconda Prompt instead.
    pause
    exit /b 1
)
call "%CONDA_BAT%" dfm
if errorlevel 1 (
    echo [ERROR] Could not activate conda environment "dfm".
    pause
    exit /b 1
)

python cura_check.py export --out cura_run
echo.
pause
